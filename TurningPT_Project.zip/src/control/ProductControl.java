package control;

import java.io.File;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import dao.MemberDAO;
import dao.ProductDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.MemberVO;
import model.ProductVO;

public class ProductControl implements Initializable {
	@FXML
	private TextField txtMemberName;
	@FXML
	private TextField txtSearch;
	@FXML
	private TextField txtMonthPay;
	@FXML
	private TextField txtMax;
	@FXML
	private TextField txtLesson;
	@FXML
	private DatePicker dpregister;
	@FXML
	private ComboBox<String> cbProgram;
	@FXML
	private ComboBox<String> cbProductJoin;
	@FXML
	private Button btnProductEdit;
	@FXML
	private Button btnProductSave;
	@FXML
	private Button btnProductDelete;
	@FXML
	private Button btnProductExit;
	@FXML
	private Button btnProductSearch;
	@FXML
	private Button btnProductTotal;
	@FXML
	private TableView<ProductVO> tableViewProduct = new TableView<>();

	ObservableList<ProductVO> data = FXCollections.observableArrayList();
	ObservableList<ProductVO> selectProduct; // ���̺����� ������ ���� ����

	int selectedIndex; // ���̺����� ������ ��ǰ���� �ε��� ����

	boolean editDelete = false; // Ȯ�� ��ư ���� ����
	ProductVO productVO = new ProductVO();
	private Stage primaryStage;

	int no; // ������ ���̺����� ������ ��ǰ�� ��ȣ ����
	File selectedFile = null;

	// �̹��� ó��

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		dpregister.setValue(LocalDate.now());
		btnProductEdit.setOnAction(event -> hanlderProductBtnEdit(event)); // ���� ��ư
		btnProductSave.setOnAction(event -> handlerProductBtnSave(event)); // ���� ��ư
		btnProductDelete.setOnAction(event -> handlerProductBtnDelete(event)); // ���� ��Ʈ
		btnProductExit.setOnAction(event -> handlerBtnProductExit(event)); // ������ ��ư
		btnProductSearch.setOnAction(event -> handlerBtnProductSearch(event)); // �˻� ��ư
		btnProductTotal.setOnAction(event -> handlerBtnTotal(event)); // ��ü�ҷ����� ��ư
		txtSearch.setOnKeyPressed(event -> entertxtProductSearch(event)); // ���ʹ����� �˻���ư ����
		tableViewProduct.setOnMousePressed(event -> setOnMousePressed(event));

		cbProgram.setItems(
				FXCollections.observableArrayList("PT", "OT", "�׷�PT", "�䰡", "�ö��׿䰡", "����", "�ʶ��׽�", "���Ǵ�", "����", "��쳪", "����"));
		cbProductJoin.setItems(FXCollections.observableArrayList("1����", "2����", "3����", "4����", "5����", "6����", "7����", "8����", "9����", "10����", "11����", "12����"));

		TableColumn colNo = new TableColumn("NO.");
		colNo.setMinWidth(40);
		colNo.setStyle("-fx-allignment: CENTER");
		colNo.setCellValueFactory(new PropertyValueFactory<>("no"));

		TableColumn colMemberName = new TableColumn("ȸ���̸�");
		colMemberName.setMinWidth(40);
		colMemberName.setCellValueFactory(new PropertyValueFactory<>("p_membername"));

		TableColumn colProgram = new TableColumn("���α׷����");
		colProgram.setMinWidth(200);
		colProgram.setCellValueFactory(new PropertyValueFactory<>("p_program"));

		TableColumn colProductjoin = new TableColumn("��ϱⰣ");
		colProductjoin.setMinWidth(40);
		colProductjoin.setCellValueFactory(new PropertyValueFactory<>("p_productjoin"));

		TableColumn colMonthPay = new TableColumn("�� ���� �ݾ�");
		colMonthPay.setMinWidth(60);
		colMonthPay.setCellValueFactory(new PropertyValueFactory<>("p_monthpay"));

		TableColumn colProductMax = new TableColumn("�ִ��ο�");
		colProductMax.setMinWidth(40);
		colProductMax.setCellValueFactory(new PropertyValueFactory<>("p_productmax"));

		TableColumn colProductLesson = new TableColumn("�����ο�");
		colProductLesson.setMinWidth(40);
		colProductLesson.setCellValueFactory(new PropertyValueFactory<>("p_productlesson"));
		TableColumn colRegister = new TableColumn("�����");
		colRegister.setMinWidth(40);
		colRegister.setCellValueFactory(new PropertyValueFactory<>("p_register"));

		tableViewProduct.setItems(data);
		tableViewProduct.getColumns().addAll(colNo, colMemberName, colProgram, colProductjoin, colMonthPay,
				colProductMax, colProductLesson, colRegister);

		totalList();
	}

	// ���̺��� ���콺 Ŭ���� �ؽ�Ʈ�ʵ忡 �ҷ���
	private void setOnMousePressed(MouseEvent event) {
		ProductVO InfoVO = tableViewProduct.getSelectionModel().getSelectedItem();
		selectedIndex = tableViewProduct.getSelectionModel().getSelectedIndex();
		
		if (event.getClickCount() != 2) {
			try {
				selectProduct = tableViewProduct.getSelectionModel().getSelectedItems();
				no = selectProduct.get(0).getNo();
			} catch (Exception e) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���α׷�����");
				alert.setHeaderText("���α׷������� �����ϴ�.");
				alert.setContentText("���α׷� ������ �Է��� �Ŀ� �����ϼ���");
				alert.showAndWait();
			}
			return;
		}
		try {
			Stage infoDialog = new Stage(StageStyle.UTILITY);
			infoDialog.initModality(Modality.WINDOW_MODAL);
			
			Parent parentInfo = FXMLLoader.load(getClass().getResource("/view/ProductInfomation.fxml"));
			infoDialog.setTitle("���α׷� ��� ��Ȳ");
			infoDialog.setResizable(false);
			Scene scene = new Scene(parentInfo);
			infoDialog.setScene(scene);
			infoDialog.show();
			if (InfoVO != null) {
				TextField infoNo = (TextField) parentInfo.lookup("#txtNoInfo");
				TextField infoName = (TextField) parentInfo.lookup("#txtMemberNameInfo");
				TextField infoAge = (TextField) parentInfo.lookup("#txtProgramInfo");
				TextField infoGender = (TextField) parentInfo.lookup("#txtProductJoinInfo");
				TextField infoPhone = (TextField) parentInfo.lookup("#txtMonthPayInfo");
				TextField infoBirth = (TextField) parentInfo.lookup("#txtMaxInfo");
				TextField infoCharacter = (TextField) parentInfo.lookup("#txtLessonInfo");
				TextField infodpDate = (TextField) parentInfo.lookup("#txtregisterInfo");
				
				  infoNo.setDisable(true); 
				  infoName.setDisable(true); 
				  infoAge.setDisable(true);
				  infoGender.setDisable(true); 
				  infoPhone.setDisable(true);
				  infoBirth.setDisable(true);
				  infoCharacter.setDisable(true);
				  infodpDate.setDisable(true);
				 
				infoNo.setText(InfoVO.getNo() + "");
				infoName.setText(InfoVO.getP_membername());
				infoGender.setText(InfoVO.getP_program());
				infoPhone.setText(InfoVO.getP_productjoin());
				infoAge.setText(InfoVO.getP_monthpay());
				infoBirth.setText(InfoVO.getP_productmax());
				infoCharacter.setText(InfoVO.getP_productlesson());
				infodpDate.setText(InfoVO.getP_register());
				
				Button btnProductInfoExit = (Button) parentInfo.lookup("#btnProductExit");

				btnProductInfoExit.setOnAction(e -> {
					infoDialog.close();
				});
			}
		} catch (Exception e) {
			System.out.println("����Ŭ��" + e);
		}
	}

	// ������ư �޼ҵ�
	private void hanlderProductBtnEdit(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/view/ProductEdit.fxml"));
			Stage EditDialog = new Stage(StageStyle.UTILITY);
			EditDialog.setTitle("���α׷� ����");
			EditDialog.setResizable(false);
			EditDialog.initModality(Modality.WINDOW_MODAL);
			EditDialog.initOwner(btnProductEdit.getScene().getWindow());
			Parent parentEdit = (Parent) loader.load();
			ProductVO productEdit = tableViewProduct.getSelectionModel().getSelectedItem();
			selectedIndex = tableViewProduct.getSelectionModel().getSelectedIndex();
			// VO ���� ������ �̸��� #���� �ҷ��ͼ� edit �� �������
			if (parentEdit != null) {
				TextField editNo = (TextField) parentEdit.lookup("#txtNoEdit");
				TextField editMemberName = (TextField) parentEdit.lookup("#txtMemberNameEdit");
				TextField editProgram = (TextField) parentEdit.lookup("#txtProgramEdit");
				TextField editProductJoin = (TextField) parentEdit.lookup("#txtProductJoinEdit");
				TextField editMonthPay = (TextField) parentEdit.lookup("#txtMonthPayEdit");
				TextField editMax = (TextField) parentEdit.lookup("#txtMaxEdit");
				TextField editLesson = (TextField) parentEdit.lookup("#txtLessonEdit");
				TextField editRegister = (TextField) parentEdit.lookup("#txtregisterEdit");
				
				editNo.setDisable(true);
				editNo.setText(productEdit.getNo() + "");
				editMemberName.setText(productEdit.getP_membername());
				editProgram.setText(productEdit.getP_program());
				editProductJoin.setText(productEdit.getP_productjoin());
				editMonthPay.setText(productEdit.getP_monthpay());
				editMax.setText(productEdit.getP_productmax());
				editLesson.setText(productEdit.getP_productlesson());
				editRegister.setText(productEdit.getP_register());
				// editImage.setText(memberEdit.getM_image());
				Button btnProductReEdit = (Button) parentEdit.lookup("#btnProductReEdit");
				Button btnProductReExit = (Button) parentEdit.lookup("#btnProductReExit");
				// ����â ������ư
				
				btnProductReEdit.setOnAction(e -> {
					ProductVO pvo = new ProductVO();
					ProductDAO pDao = new ProductDAO();
					try {
		

						pvo = new ProductVO(Integer.parseInt(editNo.getText()), editMemberName.getText(), editProgram.getText(), editProductJoin.getText(),
								editMonthPay.getText(), editMax.getText(), editLesson.getText(), editRegister.getText());
						pDao = new ProductDAO();
						pDao.getProductSave(pvo, pvo.getNo());
												
						data.removeAll(data);
						totalList();
					} catch (Exception e1) {
						System.out.println("����â ������ư" + e1);
					}
					EditDialog.close();
				});
				// ����â �������ư
				btnProductReExit.setOnAction(e -> {
					EditDialog.close();
				
				});
				Scene scene = new Scene(parentEdit);
				EditDialog.setScene(scene);
				EditDialog.setResizable(false);
				EditDialog.show();
			}
		} catch (Exception e) {
			System.out.println("������ư����" + e);

		}

	}
	// ��Ϲ�ư �޼ҵ�
	private void handlerProductBtnSave(ActionEvent event) {
		ProductVO pVO = null;
		ProductDAO pDAO = null;
		data.removeAll(data);

		try {

			pVO = new ProductVO(txtMemberName.getText(), cbProgram.getSelectionModel().getSelectedItem(),
					cbProductJoin.getSelectionModel().getSelectedItem(), txtMonthPay.getText(), txtMax.getText(),
					txtLesson.getText(), dpregister.getValue().toString());

			pDAO = new ProductDAO();
			pDAO.getProductSave(pVO, no);

			totalList();

			if (pDAO != null) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ���������");
				alert.setHeaderText("ȸ��������� ���强��");
				alert.setContentText("������ ����Ǿ����ϴ�.");
				alert.setResizable(false);
				alert.showAndWait();
			}

		} catch (Exception e) {
			System.out.println("��ǰ��Ϲ�ư ����" + e);
		}

	}

	// ��ü�ҷ����� ��ư �޼ҵ�
	private void handlerBtnTotal(ActionEvent event) {
		try {
			data.removeAll(data);
			totalList();
		} catch (Exception e) {
		}
	}

	// �˻� text���� ���ʹ����� Ȱ��ȭ
		private void entertxtProductSearch(KeyEvent event) {
			if (event.getCode() == KeyCode.ENTER) {
				Search();
			}

		}

		// �˻� �޼ҵ�
		public void Search() {
			ProductVO pVo = new ProductVO();
			ProductDAO pDao = null;
			Object[][] totalData = null;
			String searchName = "";
			boolean searchResult = false;

			try {
				searchName = txtSearch.getText().trim();
				pDao = new ProductDAO();
				pVo = pDao.getProductCheck(searchName);
				if (searchName.equals("")) {
					searchResult = true;
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("ȸ������ �˻�");
					alert.setHeaderText("ȸ���̸��� �Է����ּ���");
					alert.setContentText("�ٽ� �Է����ּ���");
					alert.showAndWait();
				}
				if (!searchName.equals("") && (pVo != null)) {
					ArrayList<String> title;
					ArrayList<ProductVO> list;

					title = pDao.getColumnName();
					int columCount = title.size();

					list = pDao.getProductTotalList(); /////
					int rowCount = list.size();

					totalData = new Object[rowCount][columCount];

					if (pVo.getP_membername().equals(searchName)) {

						// txtMemberSearch.clear();
						data.removeAll(data);
						for (int index = 0; index < rowCount; index++) {
							pVo = list.get(index);
							if (pVo.getP_membername().equals(searchName)) {
								data.add(pVo);
								searchResult = true;
							}
						}
					}
				}

				if (!searchResult) {
					System.out.println(searchName);
					txtSearch.clear();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("ȸ������ �˻�");
					alert.setHeaderText(searchName + "ȸ���� ����Ʈ�� �����ϴ�.");
					alert.setContentText("�ٽ� �˻��ϼ���");
					alert.showAndWait();

				}
			} catch (Exception e) {
				System.out.println("�˻���ư����" + e);
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ȸ������ �˻�����");
				alert.setHeaderText(searchName + "ȸ������ �˻��� ������ �߻��Ͽ����ϴ�.");
				alert.setContentText("�ٽ� �ϼ���");
				alert.showAndWait();
			}
		}

		// �˻���ư �޼ҵ�
		private void handlerBtnProductSearch(ActionEvent event) {
			Search();
		}


	// ȸ�� ��ü ����Ʈ
	public void totalList() {
		Object[][] totalData;

		ProductDAO pDao = new ProductDAO();
		ProductVO pVo = new ProductVO();
		ArrayList<String> title;
		ArrayList<ProductVO> list;

		title = pDao.getColumnName();
		int columnCount = title.size();

		list = pDao.getProductTotalList();
		int rowCount = list.size();
		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			pVo = list.get(index);
			data.add(pVo);
		}
	}

	// ������ư �޼ҵ�
	private void handlerProductBtnDelete(ActionEvent event) {
		ProductDAO pDao = null;
		pDao = new ProductDAO();

		try {
			pDao.getProductDelete(tableViewProduct.getSelectionModel().getSelectedItem().getNo());
			data.removeAll(data);
			totalList();

		} catch (Exception e) {
			System.out.println("getProductDelete" + e);
		}
	}

	// ������ ��ư �޼ҵ�
	private void handlerBtnProductExit(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/InfoView.fxml"));
			Parent InfoView = (Parent) loader.load();
			Scene scane = new Scene(InfoView);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ｺ�� �λ����");
			mainStage.setScene(scane);
			mainStage.setResizable(false);

			Stage oldStage = (Stage) btnProductExit.getScene().getWindow();
			oldStage.close();
			mainStage.show();
		} catch (Exception e) {
			System.out.println("btnProductExit ����" + e);
			e.getStackTrace();
		}
	}

}
