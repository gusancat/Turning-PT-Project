package control;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import dao.MemberDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.MemberVO;

public class MemberControl implements Initializable {
	@FXML
	private ImageView imageViewMember; // ȸ�����â �̹�����
	@FXML
	private TextField txtMemberName; // TextField �̸�
	@FXML
	private TextField txtMemberPhone; // TextField ��ȭ��ȣ
	@FXML
	private TextField txtMemberAge; // TextField ����
	@FXML
	private TextField txtMemberBirth; // TextField �������
	@FXML
	private TextField txtMemberSearch; // TextField �˻�
	@FXML
	private TextField txtsessionPT; // TextField PT���� ȸ��
	@FXML
	private TextField txtsessionOT; // TextField OT���� ȸ��
	@FXML
	private ToggleGroup genderGroup; // ToggleGroup ����
	@FXML
	private ToggleGroup CharacterGroup; // ToggleGroup �米��
	@FXML
	private ToggleGroup typeGroup; // ToggleGroup ȸ������(PT,OT)
	@FXML
	private ToggleGroup levelGroup; // ToggleGroup ȸ������(PT,OT)
	@FXML
	private Button btnMemberSave; // �����ư
	@FXML
	private Button btnMemberSearch; // �˻���ư
	@FXML
	private Button btnMemberDelete; // ������ư
	@FXML
	private Button btnMemberEdit; // ������ư
	@FXML
	private Button btnMemberBack; // �ڷΰ����ư
	@FXML
	private Button btnMemberInit; // �ʱ�ȭ��ư
	@FXML
	private Button btnMemberImageAdd; // �̹����߰� ��ư
	@FXML
	private Button btnMemberReEdit; // ����â ������ư
	@FXML
	private Button btnMemberReExit; // ����â �������ư
	@FXML
	private Button btnMemberTotal; // ��ü ��ư
	@FXML
	private RadioButton rbMale; // RadioButton ��
	@FXML
	private RadioButton rbFemale; // RadioButton ��
	@FXML
	private RadioButton rbHigh; // RadioButton ��
	@FXML
	private RadioButton rbMiddle; // RadioButton ��
	@FXML
	private RadioButton rbLow; // RadioButton ��
	@FXML
	private RadioButton rbPT; // RadioButton PT
	@FXML
	private RadioButton rbOT; // RadioButton OT
	@FXML
	private RadioButton rbHighL; // RadioButton ��
	@FXML
	private RadioButton rbMiddleL; // RadioButton ��
	@FXML
	private RadioButton rbLowL; // RadioButton ��
	@FXML
	private TableView<MemberVO> tableViewMember = new TableView<>();
	@FXML
	private DatePicker dpDate; // �����
	@FXML
	private DatePicker dpDateAnd; // ��ϸ�����
	// ����â
	@FXML
	private TextField txteditNo; // RadioButton ȸ������â ��ȣ
	@FXML
	private TextField txteditName; // RadioButton ȸ������â �̸�
	@FXML
	private TextField txteditGender; // RadioButton ȸ������â ����
	@FXML
	private TextField txteditPhone; // RadioButton ȸ������â ��ȭ��ȣ
	@FXML
	private TextField txteditAge; // RadioButton ȸ������â ����
	@FXML
	private TextField txteditBirth; // RadioButton ȸ������â ����
	@FXML
	private TextField txteditCharacter; // RadioButton ȸ������â �米��
	@FXML
	private TextField txtRuntime; // TextField �ٹ��ð�
	@FXML
	private TextField txtRunday; // TextField �ٹ�����
	@FXML
	private TextField txtRundate; // TextField �ٹ��ϼ�
	@FXML
	private TextField txtSmoking; // TextField ��������
	@FXML
	private TextField txtDrinking; // TextField ���ֿ���
	@FXML
	private TextField txtReason; // TextField �����
	@FXML
	private TextField txtRegiNo; // TextField ��ϰ��� ��
	@FXML
	private ComboBox<String> cbMedical; // ComboBox<String> �λ��� ����
	@FXML
	private TextField dpDateEdit; // RadioButton ȸ������â ����
	@FXML
	private TextField dpDateAndEdit;
	@FXML
	private TextField txtTrainer;// ���Ʈ���̳�
	@FXML
	private TextField dpDateAndInfo;
	@FXML
	private TextField txtMemberJob;
	@FXML
	private Button btnMemberInfoExit;

	ObservableList<MemberVO> data = FXCollections.observableArrayList();

	ObservableList<MemberVO> selectMember = null; // ���̺����� ������ ���� ����

	int selectedIndex; // ���̺����� ������ �л����� �ε��� ����

	boolean editDelete = false; // Ȯ�� ��ư ���� ����
	MemberVO memberVO = new MemberVO();
	private Stage primaryStage;

	String SelectFileName = ""; // �̹��� ���ϸ�
	String localUrl = ""; // �̹��� ���ϰ��
	Image localImage;
	int no; // ������ ���̺����� ������ �л��� ��ȣ ����
	File selectedFile = null;

	// �̹��� ó��
	private File dirSave = new File("C:/images"); // �̹��� ������ ������ �Ű������� ���� ��ü ����
	private File file = null; // �̹��� �ҷ��� ������ ������ ���� ��ü ����

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnMemberSave.setOnAction(event -> handlerBtnMemberSave(event)); // ���� ��ư
		btnMemberSearch.setOnAction(event -> handlerBtnMemberSearch(event)); // �˻� ��ư
		btnMemberDelete.setOnAction(event -> handlerBtnMemberDelete(event)); // ���� ��ư
		btnMemberEdit.setOnAction(event -> handlerBtnMemberEdit(event)); // ���� ��ư
		btnMemberInit.setOnAction(event -> handlerBtnMemberInit(event)); // �ʱ�ȭ ��ư
		btnMemberBack.setOnAction(event -> hanldlerBtnMemberBack(event)); // �ڷΰ��� ��ư
		btnMemberImageAdd.setOnAction(event -> handlerBtnMemberImageAdd(event));// �̹����߰� ��ư
		btnMemberTotal.setOnAction(event -> handlerBtnTotal(event)); // ȸ����ü�ҷ����� ��ư
		tableViewMember.setOnMouseClicked(event -> handlerClickInfomation(event)); // ����Ŭ������ ȸ������â �ҷ���
		txtMemberSearch.setOnKeyPressed(event -> enterMemberSearch(event)); // �˻�â���� ���� ������ �˻���ư ����
		tableViewMember.setOnMousePressed(event -> setOnMousePressd(event));

		cbMedical.setItems(FXCollections.observableArrayList("��õ�� ���ΰ���", "��õ�� �ܺΰ���", "��õ�� ���ΰ���", "��õ���ܺ� ����", "����"));

		// ���̺� �� �÷��̸� ����
		TableColumn colNo = new TableColumn("NO.");
		colNo.setMinWidth(40);
		colNo.setStyle("-fx-allignment: CENTER");
		colNo.setCellValueFactory(new PropertyValueFactory<>("no"));

		TableColumn colName = new TableColumn("�̸�");
		colName.setMinWidth(80);
		colName.setCellValueFactory(new PropertyValueFactory<>("m_name"));

		TableColumn colAge = new TableColumn("����");
		colAge.setMinWidth(40);
		colAge.setCellValueFactory(new PropertyValueFactory<>("m_age"));

		TableColumn colGender = new TableColumn("����");
		colGender.setMinWidth(30);
		colGender.setCellValueFactory(new PropertyValueFactory<>("m_gender"));

		TableColumn colPhone = new TableColumn("��ȭ��ȣ");
		colPhone.setMinWidth(80);
		colPhone.setCellValueFactory(new PropertyValueFactory<>("m_phone"));

		TableColumn colBirth = new TableColumn("����");
		colBirth.setMinWidth(80);
		colBirth.setCellValueFactory(new PropertyValueFactory<>("m_birth"));

		TableColumn colJob = new TableColumn("����");
		colJob.setMinWidth(80);
		colJob.setCellValueFactory(new PropertyValueFactory<>("m_job"));

		TableColumn colCharacter = new TableColumn("�米��");
		colCharacter.setMinWidth(40);
		colCharacter.setCellValueFactory(new PropertyValueFactory<>("m_character"));

		TableColumn colRegister = new TableColumn("�����");
		colRegister.setMinWidth(40);
		colRegister.setCellValueFactory(new PropertyValueFactory<>("m_register"));

		TableColumn colRegisterAnd = new TableColumn("��ϸ�����");
		colRegisterAnd.setMinWidth(40);
		colRegisterAnd.setCellValueFactory(new PropertyValueFactory<>("m_registerand"));

		TableColumn colRegiNo = new TableColumn("��ϰ��� ��");
		colRegiNo.setMinWidth(40);
		colRegiNo.setCellValueFactory(new PropertyValueFactory<>("m_regiNo"));

		TableColumn colTrainer = new TableColumn("���Ʈ���̳�");
		colTrainer.setMinWidth(40);
		colTrainer.setCellValueFactory(new PropertyValueFactory<>("m_trainer"));

		TableColumn colType = new TableColumn("ȸ������(PT,OT)");
		colType.setMinWidth(40);
		colType.setCellValueFactory(new PropertyValueFactory<>("m_type"));

		TableColumn colSessionPT = new TableColumn("PT���� ��");
		colSessionPT.setMinWidth(40);
		colSessionPT.setCellValueFactory(new PropertyValueFactory<>("m_sessionPT"));

		TableColumn colSessionOT = new TableColumn("OT���� ��");
		colSessionOT.setMinWidth(40);
		colSessionOT.setCellValueFactory(new PropertyValueFactory<>("m_sessionOT"));

		TableColumn colLevel = new TableColumn("�뵿�ǰ���");
		colLevel.setMinWidth(40);
		colLevel.setCellValueFactory(new PropertyValueFactory<>("m_level"));

		TableColumn colRuntime = new TableColumn("�ٹ��ð�");
		colRuntime.setMinWidth(40);
		colRuntime.setCellValueFactory(new PropertyValueFactory<>("m_runtime"));

		TableColumn colRunday = new TableColumn("�ٹ�����");
		colRunday.setMinWidth(40);
		colRunday.setCellValueFactory(new PropertyValueFactory<>("m_runday"));

		TableColumn colRundate = new TableColumn("�ٹ��ϼ�");
		colRundate.setMinWidth(40);
		colRundate.setCellValueFactory(new PropertyValueFactory<>("m_rundate"));

		TableColumn colSmoking = new TableColumn("��������");
		colSmoking.setMinWidth(40);
		colSmoking.setCellValueFactory(new PropertyValueFactory<>("m_smoking"));

		TableColumn colDrinking = new TableColumn("���ֿ���");
		colDrinking.setMinWidth(40);
		colDrinking.setCellValueFactory(new PropertyValueFactory<>("m_drinking"));

		TableColumn colReason = new TableColumn("�����");
		colReason.setMinWidth(40);
		colReason.setCellValueFactory(new PropertyValueFactory<>("m_reason"));

		TableColumn colMedical = new TableColumn("�λ�����");
		colMedical.setMinWidth(40);
		colMedical.setCellValueFactory(new PropertyValueFactory<>("m_medical"));

		TableColumn colImage = new TableColumn("�̹���");
		colImage.setMinWidth(60);
		colImage.setCellValueFactory(new PropertyValueFactory<>("m_image"));

		tableViewMember.setItems(data);
		tableViewMember.getColumns().addAll(colNo, colName, colAge, colGender, colPhone, colBirth, colJob, colCharacter,
				colRegister, colRegisterAnd, colRegiNo, colTrainer, colType, colSessionPT, colSessionOT, colLevel,
				colRuntime, colRunday, colRundate, colSmoking, colDrinking, colReason, colMedical, colImage);

		// ȸ�� ��ü ����
		totalList();

		// �⺻ �̹���
		localUrl = "/image/default.png";
		localImage = new Image(localUrl, false);
		imageViewMember.setImage(localImage);

	}

	// ���̺���
	private void setOnMousePressd(MouseEvent event) {
		selectMember = tableViewMember.getSelectionModel().getSelectedItems();
		selectedIndex = tableViewMember.getSelectionModel().getSelectedIndex();

		try {
			System.out.println("Ŭ������");
			// ���̺��� Ŭ���ϸ� �ش�ȸ�� ������ �ڵ������ؽ�Ʈ�ʵ忡 ��
			txtMemberPhone.setText(selectMember.get(0).getM_phone());
			txtMemberName.setText(selectMember.get(0).getM_name());
			txtMemberAge.setText(selectMember.get(0).getM_age());
			txtMemberBirth.setText(selectMember.get(0).getM_birth());
			// ���� ��۹�ư
			if (selectMember.get(0).getM_gender().equals("��")) {
				genderGroup.selectToggle(rbMale);
			} else {
				genderGroup.selectToggle(rbFemale);
			}
			// �米�� ��۹�ư
			if (selectMember.get(0).getM_character().equals("��")) {
				CharacterGroup.selectToggle(rbHigh);
			} else if (selectMember.get(0).getM_character().equals("��")) {
				CharacterGroup.selectToggle(rbMiddle);
			} else {
				CharacterGroup.selectToggle(rbLow);
			}
			txtMemberJob.setText(selectMember.get(0).getM_job());
			txtRegiNo.setText(selectMember.get(0).getM_regiNo());
			txtTrainer.setText(selectMember.get(0).getM_trainer());
			if (selectMember.get(0).getM_type().equals("PT")) {
				typeGroup.selectToggle(rbPT);
			} else {
				typeGroup.selectToggle(rbOT);
			}
			txtsessionPT.setText(selectMember.get(0).getM_sessionPT());
			txtsessionOT.setText(selectMember.get(0).getM_sessionOT());
			txtRuntime.setText(selectMember.get(0).getM_runtime());
			txtRunday.setText(selectMember.get(0).getM_runday());
			txtRundate.setText(selectMember.get(0).getM_rundate());
			txtSmoking.setText(selectMember.get(0).getM_smoking());
			txtDrinking.setText(selectMember.get(0).getM_drinking());
			txtReason.setText(selectMember.get(0).getM_reason());
			if (selectMember.get(0).getM_level().equals("��")) {
				levelGroup.selectToggle(rbHighL);
			} else if (selectMember.get(0).getM_character().equals("��")) {
				levelGroup.selectToggle(rbMiddleL);
			} else {
				levelGroup.selectToggle(rbLowL);
			}
			// cbyear.getSelectionModel().select(selectMember.get(0).getM_birth());

			/*
			 * Image selectedImg = new Image(selectMember.get(0).getM_image());
			 * imageViewMember.setImage(selectedImg);
			 */

			editDelete = true;
		} catch (Exception e) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ȸ������ ���� ����");
			alert.setHeaderText("ȸ�������� �Է��Ͻÿ�.");
			alert.setContentText("�������� �����ϼ���!");
			alert.showAndWait();
		}
	}

	// ȸ����ü�ҷ����� ��ư �޼ҵ�
	private void handlerBtnTotal(ActionEvent event) {
		try {
			data.removeAll(data);
			totalList();
		} catch (Exception e) {
		}
	}

	// ȸ�� ��ü ����Ʈ
	public void totalList() {
		Object[][] totalData;

		MemberDAO mDao = new MemberDAO();
		MemberVO mVo = new MemberVO();
		ArrayList<String> title;
		ArrayList<MemberVO> list;

		title = mDao.getColumnName();
		int columnCount = title.size();

		list = mDao.getMemberTotalList(); // getMemberTotalList �� �ҷ���
		int rowCount = list.size();
		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			mVo = list.get(index);
			data.add(mVo);
		}
	}

	// �˻� text���� ���ʹ����� Ȱ��ȭ
	private void enterMemberSearch(KeyEvent event) {
		if (event.getCode() == KeyCode.ENTER) {
			entertxtMemberSearch();
		}

	}

	// �˻� �޼ҵ�
	public void entertxtMemberSearch() {
		MemberVO mVo = new MemberVO();
		MemberDAO mDao = null;
		Object[][] totalData = null;
		String searchName = "";
		boolean searchResult = false;

		try {
			searchName = txtMemberSearch.getText().trim();
			mDao = new MemberDAO();
			mVo = mDao.getMemberCheck(searchName);
			if (searchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ������ �˻�");
				alert.setHeaderText("ȸ���̸��� �Է����ּ���");
				alert.setContentText("�ٽ� �Է����ּ���");
				alert.showAndWait();
			}
			if (!searchName.equals("") && (mVo != null)) {
				ArrayList<String> title;
				ArrayList<MemberVO> list;

				title = mDao.getColumnName();
				int columCount = title.size();

				list = mDao.getMemberTotalList(); /////
				int rowCount = list.size();

				totalData = new Object[rowCount][columCount];

				if (mVo.getM_name().equals(searchName)) {

					// txtMemberSearch.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						mVo = list.get(index);
						if (mVo.getM_name().equals(searchName)) {
							data.add(mVo);
							searchResult = true;
						}
					}
				}
			}

			if (!searchResult) {
				System.out.println(searchName);
				txtMemberSearch.clear();
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ������ �˻�");
				alert.setHeaderText(searchName + "ȸ���� ����Ʈ�� �����ϴ�.");
				alert.setContentText("�ٽ� �˻��ϼ���");
				alert.showAndWait();

			}
		} catch (Exception e) {
			System.out.println("�˻���ư����" + e);
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ȸ������ �˻�����");
			alert.setHeaderText(searchName + "ȸ������ �˻��� ������ �߻��Ͽ����ϴ�.");
			alert.setContentText("�ٽ� �ϼ���");
			alert.showAndWait();
		}
	}

	// �˻���ư �޼ҵ�
	private void handlerBtnMemberSearch(ActionEvent event) {
		entertxtMemberSearch();
	}

	// �ʱ�ȭ��ư �޼ҵ�
	public void init() {
		txtMemberName.clear();
		txtMemberName.setEditable(true);
		genderGroup.selectToggle(null);
		rbMale.setDisable(false);
		rbFemale.setDisable(false);
		CharacterGroup.selectToggle(null);
		rbHigh.setDisable(false);
		rbMiddle.setDisable(false);
		rbLow.setDisable(false);
		txtMemberPhone.clear();
		txtMemberPhone.setEditable(true);
		txtMemberAge.clear();
		txtMemberAge.setEditable(true);
		txtMemberBirth.clear();
		txtMemberBirth.setEditable(true);
		txtMemberJob.clear();
		txtMemberJob.setEditable(true);
		txtMemberSearch.clear();
		txtMemberSearch.setEditable(true);
		dpDate.setValue(LocalDate.now());
		dpDateAnd.setValue(LocalDate.now());
		txtRegiNo.clear();
		txtRegiNo.setEditable(true);
		txtTrainer.clear();
		txtTrainer.setEditable(true);
		typeGroup.selectToggle(null);
		txtsessionPT.clear();
		txtsessionPT.setEditable(true);
		txtsessionOT.clear();
		txtsessionOT.setEditable(true);
		levelGroup.selectToggle(null);
		txtRuntime.clear();
		txtRuntime.setEditable(true);
		txtRunday.clear();
		txtRunday.setEditable(true);
		txtRundate.clear();
		txtRundate.setEditable(true);
		txtSmoking.clear();
		txtSmoking.setEditable(true);
		txtDrinking.clear();
		txtDrinking.setEditable(true);
		txtReason.clear();
		txtReason.setEditable(true);
		cbMedical.setDisable(false);

	}

	// ȸ������ �ʱ�ȭ��ư �޼ҵ�
	private void handlerBtnMemberInit(ActionEvent event) {
		txtMemberName.clear();
		txtMemberName.setEditable(true);
		genderGroup.selectToggle(null);
		rbMale.setDisable(false);
		rbFemale.setDisable(false);
		CharacterGroup.selectToggle(null);
		rbHigh.setDisable(false);
		rbMiddle.setDisable(false);
		rbLow.setDisable(false);
		txtMemberPhone.clear();
		txtMemberPhone.setEditable(true);
		txtMemberAge.clear();
		txtMemberAge.setEditable(true);
		txtMemberBirth.clear();
		txtMemberBirth.setEditable(true);
		txtMemberJob.clear();
		txtMemberJob.setEditable(true);
		txtMemberSearch.clear();
		txtMemberSearch.setEditable(true);
		dpDate.setValue(LocalDate.now());
		dpDateAnd.setValue(LocalDate.now());
		txtRegiNo.clear();
		txtRegiNo.setEditable(true);
		txtTrainer.clear();
		txtTrainer.setEditable(true);
		typeGroup.selectToggle(null);
		txtsessionPT.clear();
		txtsessionPT.setEditable(true);
		txtsessionOT.clear();
		txtsessionOT.setEditable(true);
		levelGroup.selectToggle(null);
		txtRuntime.clear();
		txtRuntime.setEditable(true);
		txtRunday.clear();
		txtRunday.setEditable(true);
		txtRundate.clear();
		txtRundate.setEditable(true);
		txtSmoking.clear();
		txtSmoking.setEditable(true);
		txtDrinking.clear();
		txtDrinking.setEditable(true);
		txtReason.clear();
		txtReason.setEditable(true);
		cbMedical.setDisable(false);

	}

	// ȸ������ ������ư �޼ҵ�
	private void handlerBtnMemberDelete(ActionEvent event) {
		MemberDAO mDao = null;
		mDao = new MemberDAO();

		try {
			mDao.getMemberDelete(tableViewMember.getSelectionModel().getSelectedItem().getNo());
			data.removeAll(data);
			totalList();

		} catch (Exception e) {
			System.out.println("MemberCon" + e);
		}
	}

	// �ڷΰ����ư �޼ҵ�
	private void hanldlerBtnMemberBack(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/InfoView.fxml"));
			Parent InfoView = (Parent) loader.load();
			Scene scane = new Scene(InfoView);
			Stage mainStage = new Stage();
			mainStage.setTitle("�α���");
			mainStage.setScene(scane);
			mainStage.setResizable(false);

			Stage oldStage = (Stage) btnMemberBack.getScene().getWindow();
			oldStage.close();
			mainStage.show();
		} catch (Exception e) {
			System.out.println("�ڷΰ����ư ����" + e);
			e.getStackTrace();
		}
	}

	// ȸ������ ��Ϲ�ư �޼ҵ�
	private void handlerBtnMemberSave(ActionEvent event) {
		MemberVO memberVO = null;
		MemberDAO memberDAO = null;
		data.removeAll(data);
		File dirMake = new File(dirSave.getAbsolutePath());

		// �̹��� ���� ���� ����
		if (!dirMake.exists()) {
			dirMake.mkdir();
		}

		// �̹��� �������� �޼ҵ�
		String fileName = imageSave(selectedFile);

		try {

			memberVO = new MemberVO(txtMemberName.getText(), txtMemberAge.getText(),
					genderGroup.getSelectedToggle().getUserData().toString(), txtMemberPhone.getText(),
					txtMemberBirth.getText(), txtMemberJob.getText(),
					CharacterGroup.getSelectedToggle().getUserData().toString(), dpDate.getValue().toString(),
					dpDateAnd.getValue().toString(), txtRegiNo.getText(), txtTrainer.getText(),
					typeGroup.getSelectedToggle().getUserData().toString(), txtsessionPT.getText(),
					txtsessionOT.getText(), levelGroup.getSelectedToggle().getUserData().toString(),
					txtRuntime.getText(), txtRunday.getText(), txtRundate.getText(), txtSmoking.getText(),
					txtDrinking.getText(), txtReason.getText(),
					cbMedical.getSelectionModel().getSelectedItem().toString(), imageViewMember.getImage().toString());

			memberDAO = new MemberDAO();
			memberDAO.getMemberInfoSave(memberVO);

			totalList();

			if (memberDAO != null) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ���������");
				alert.setHeaderText("ȸ��������� ���强��");
				alert.setContentText("������ ����Ǿ����ϴ�.");
				alert.setResizable(false);
				alert.showAndWait();
			}

		} catch (Exception e) {
			System.out.println("�̹������� ���� ����" + e);
		}
	}

	// �̹��� ���� �޼ҵ�
	public boolean imageDelete(String fileName) {
		boolean result = false;
		try {
			File fileDelete = new File(dirSave.getAbsolutePath() + "\\" + fileName); // �����̹��� ����
			if (fileDelete.exists() && fileDelete.isFile()) {
				result = fileDelete.delete();
				// �⺻ �̹���
				localUrl = "/image/default.png";
				localImage = new Image(localUrl, false);
				imageViewMember.setImage(localImage);
			}
		} catch (Exception e) {
			System.out.println("�̹��� ���� ����" + e);
			result = false;
		}
		return result;
	}

	// �̹��� ���� �޼ҵ�
	public String imageSave(File file) {
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;

		int data = -1;
		String fileName = null;
		try {
			// �̹��� ���ϻ���
			fileName = "member" + System.currentTimeMillis() + "_" + file.getName();
			bis = new BufferedInputStream(new FileInputStream(file));
			bos = new BufferedOutputStream(new FileOutputStream(dirSave.getAbsolutePath() + "\\" + fileName));
			// ������ �̹��� ���� InputStream �� �������� �̸����� ���� -1
			while ((data = bis.read()) != -1) {
				bos.write(data);
				bos.flush();
			}
		} catch (Exception e) {
			e.getMessage();
		} finally {
			try {
				if (bos != null) {
					bos.close();
				}
				if (bis != null) {
					bis.close();
				}
			} catch (IOException e) {

			}
		}
		return fileName;

	}

	// �̹����߰� ��ư �޼ҵ�
	private void handlerBtnMemberImageAdd(ActionEvent event) {
		FileChooser fileChooser = new FileChooser();
		fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Image File", "*.png", "*.jpg", "*.gif"));
		try {
			selectedFile = fileChooser.showOpenDialog(primaryStage);
			if (selectedFile != null) {
				// �̹��� ���� ���
				localUrl = selectedFile.toURI().toURL().toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		localImage = new Image(localUrl, false);
		imageViewMember.setImage(localImage);
		imageViewMember.setFitHeight(250);
		imageViewMember.setFitWidth(230);
		btnMemberSave.setDisable(false);

		if (selectedFile != null) {
			SelectFileName = selectedFile.getName();
		}

	}

	// ���̺��� ����Ŭ���� ȸ������ �ҷ���
	public void handlerClickInfomation(MouseEvent event) {
		MemberVO InfoVO = tableViewMember.getSelectionModel().getSelectedItem();
		selectedIndex = tableViewMember.getSelectionModel().getSelectedIndex();
		String image = tableViewMember.getSelectionModel().getSelectedItem().getM_image();
		//tableViewMember.getSelectionModel().getSelectedItem().getM_image();
		
		if (event.getClickCount() != 2) {
			try {
				selectMember = tableViewMember.getSelectionModel().getSelectedItems();
				no = selectMember.get(0).getNo();
			} catch (Exception e) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ȸ������");
				alert.setHeaderText("ȸ�������� �����ϴ�.");
				alert.setContentText("ȸ�� ������ �Է��� �Ŀ� �����ϼ���");
				alert.showAndWait();
			}
			return;
		}
		try {
			Stage infoDialog = new Stage(StageStyle.UTILITY);
			infoDialog.initModality(Modality.WINDOW_MODAL);
			infoDialog.setTitle("ȸ������");
			
			Parent parentInfo = FXMLLoader.load(getClass().getResource("/view/MemberInfomation.fxml"));
			Scene scene = new Scene(parentInfo);
			infoDialog.setScene(scene);
			infoDialog.show();
			if (InfoVO != null) {
				TextField infoNo = (TextField) parentInfo.lookup("#txtInfoNo");
				TextField infoName = (TextField) parentInfo.lookup("#txtInfoName");
				TextField infoAge = (TextField) parentInfo.lookup("#txtInfoAge");
				TextField infoGender = (TextField) parentInfo.lookup("#txtInfoGender");
				TextField infoPhone = (TextField) parentInfo.lookup("#txtInfoPhone");
				TextField infoBirth = (TextField) parentInfo.lookup("#txtInfoBirth");
				TextField infoJob = (TextField) parentInfo.lookup("#txtInfojob");
				TextField infoCharacter = (TextField) parentInfo.lookup("#txtInfoCharacter");
				TextField infodpDate = (TextField) parentInfo.lookup("#dpDateInfo");
				TextField infodpDateAnd = (TextField) parentInfo.lookup("#dpDateAndInfo");
				TextField infoRegiNo = (TextField) parentInfo.lookup("#txtRegiNoInfo");
				TextField infoTrainer = (TextField) parentInfo.lookup("#txtInfoTrainer");
				TextField infoType = (TextField) parentInfo.lookup("#txtInfoType");
				TextField infoSessionPT = (TextField) parentInfo.lookup("#txtInfoSessionPT");
				TextField infoSessionOT = (TextField) parentInfo.lookup("#txtInfoSessionOT");
				TextField infoLevel = (TextField) parentInfo.lookup("#txtInfoLevel");
				TextField infoRuntime = (TextField) parentInfo.lookup("#txtInfoRuntime");
				TextField infoRunday = (TextField) parentInfo.lookup("#txtInfoRunday");
				TextField infoRundate = (TextField) parentInfo.lookup("#txtInfoRundate");
				TextField infoSmoking = (TextField) parentInfo.lookup("#txtInfoSmoking");
				TextField infoDrinking = (TextField) parentInfo.lookup("#txtInfoDrinking");
				TextField infoReason = (TextField) parentInfo.lookup("#txtInfoReason");
				TextField infoMedical = (TextField) parentInfo.lookup("#txtInfoMedical");
				System.out.println("����Ŭ��1");
				
				  infoNo.setDisable(true); 
				  infoName.setDisable(true); 
				  infoAge.setDisable(true);
				  infoGender.setDisable(true); 
				  infoPhone.setDisable(true);
				  infoBirth.setDisable(true);
				  infoJob.setDisable(true);
				  infoCharacter.setDisable(true);
				  infodpDate.setDisable(true);
				  infodpDateAnd.setDisable(true);
				  infoRegiNo.setDisable(true);
				  infoTrainer.setDisable(true); 
				  infoType.setDisable(true);
				  infoSessionPT.setDisable(true); 
				  infoSessionOT.setDisable(true);
				  infoLevel.setDisable(true); 
				  infoRuntime.setDisable(true);
				  infoRunday.setDisable(true); 
				  infoRundate.setDisable(true);
				  infoSmoking.setDisable(true); 
				  infoDrinking.setDisable(true);
				  infoReason.setDisable(true); 
				  infoMedical.setDisable(true);
				 
				infoNo.setText(InfoVO.getNo() + "");
				System.out.println("no");
				infoName.setText(InfoVO.getM_name());
				System.out.println("name");
				infoGender.setText(InfoVO.getM_gender());
				System.out.println("gender");
				infoPhone.setText(InfoVO.getM_phone());
				System.out.println("phone");
				infoAge.setText(InfoVO.getM_age());
				System.out.println("age");
				infoBirth.setText(InfoVO.getM_birth());
				System.out.println("birth");
				infoCharacter.setText(InfoVO.getM_character());
				System.out.println("character");
				
				infoJob.setText(InfoVO.getM_job());
				System.out.println("job");
				
				infodpDate.setText(InfoVO.getM_register());
				System.out.println("register");
				infodpDateAnd.setText(InfoVO.getM_registerand());
				System.out.println("registerand");
				infoRegiNo.setText(InfoVO.getM_regiNo());
				System.out.println("regino");
				infoTrainer.setText(InfoVO.getM_trainer());
				System.out.println("trainer");
				infoType.setText(InfoVO.getM_type());
				System.out.println("type");
				infoSessionPT.setText(InfoVO.getM_sessionPT());
				System.out.println("pt");
				infoSessionOT.setText(InfoVO.getM_sessionOT());
				System.out.println("ot");
				infoLevel.setText(InfoVO.getM_level());
				System.out.println("level");
				infoRuntime.setText(InfoVO.getM_runtime());
				System.out.println("runtime");
				infoRunday.setText(InfoVO.getM_runday());
				System.out.println("runday");
				infoRundate.setText(InfoVO.getM_rundate());
				System.out.println("rundate");
				infoSmoking.setText(InfoVO.getM_smoking());
				System.out.println("smoking");
				infoDrinking.setText(InfoVO.getM_drinking());
				System.out.println("drinking");
				infoReason.setText(InfoVO.getM_reason());
				System.out.println("reason");
				infoMedical.setText(InfoVO.getM_medical());
				System.out.println("medical");
				System.out.println("����Ŭ��6");
				// editImage.setText(memberEdit.getM_image());

				Button btnMemberInfoExit = (Button) parentInfo.lookup("#btnMemberInfoExit");

				btnMemberInfoExit.setOnAction(e -> {
					infoDialog.close();
				});
				/*
				 * Scene scene1 = new Scene(parentInfo); System.out.println("222");
				 * infoDialog.setScene(scene1); System.out.println("333");
				 * infoDialog.setResizable(false); System.out.println("444"); infoDialog.show();
				 * System.out.println("��");
				 */
			}

		} catch (Exception e) {
			System.out.println("����Ŭ��" + e);
		}
	}

	// ������ư �޼ҵ�
	private void handlerBtnMemberEdit(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/view/MemberEdit.fxml"));
			Stage EditDialog = new Stage(StageStyle.UTILITY);
			EditDialog.initModality(Modality.WINDOW_MODAL);
			EditDialog.initOwner(btnMemberEdit.getScene().getWindow());
			Parent parentEdit = (Parent) loader.load();
			EditDialog.setTitle("ȸ����������");
			MemberVO memberEdit = tableViewMember.getSelectionModel().getSelectedItem();
			selectedIndex = tableViewMember.getSelectionModel().getSelectedIndex();
			String imgpath = tableViewMember.getSelectionModel().getSelectedItem().getM_image();

			// VO ���� ������ �̸��� #���� �ҷ��ͼ� edit �� �������
			if (memberEdit != null) {
				TextField editNo = (TextField) parentEdit.lookup("#txteditNo");
				TextField editName = (TextField) parentEdit.lookup("#txteditName");
				TextField editAge = (TextField) parentEdit.lookup("#txteditAge");
				TextField editGender = (TextField) parentEdit.lookup("#txteditGender");
				TextField editPhone = (TextField) parentEdit.lookup("#txteditPhone");
				TextField editBirth = (TextField) parentEdit.lookup("#txteditBirth");
				TextField editJob = (TextField) parentEdit.lookup("#txteditJob");
				TextField editCharacter = (TextField) parentEdit.lookup("#txteditCharacter");
				TextField editdpDate = (TextField) parentEdit.lookup("#dpDateEdit");
				TextField editdpDateAnd = (TextField) parentEdit.lookup("#dpDateAndEdit");
				TextField editRegiNo = (TextField) parentEdit.lookup("#txtRegiNoEdit");
				TextField editTrainer = (TextField) parentEdit.lookup("#txteditTrainer");
				TextField editType = (TextField) parentEdit.lookup("#txteditType");
				TextField editSessionPT = (TextField) parentEdit.lookup("#txteditSessionPT");
				TextField editSessionOT = (TextField) parentEdit.lookup("#txteditSessionOT");
				TextField editLevel = (TextField) parentEdit.lookup("#txteditLevel");
				TextField editRuntime = (TextField) parentEdit.lookup("#txteditRuntime");
				TextField editRunday = (TextField) parentEdit.lookup("#txteditRunday");
				TextField editRundate = (TextField) parentEdit.lookup("#txteditRundate");
				TextField editSmoking = (TextField) parentEdit.lookup("#txteditSmoking");
				TextField editDrinking = (TextField) parentEdit.lookup("#txteditDrinking");
				TextField editReason = (TextField) parentEdit.lookup("#txteditReason");
				TextField editMedical = (TextField) parentEdit.lookup("#txteditMedical");
				// TextField editImage = (TextField) parentEdit.lookup("#txteditImage");
				editNo.setDisable(true);
				editNo.setText(memberEdit.getNo() + "");
				editName.setText(memberEdit.getM_name());
				editGender.setText(memberEdit.getM_gender());
				editPhone.setText(memberEdit.getM_phone());
				editAge.setText(memberEdit.getM_age());
				editBirth.setText(memberEdit.getM_birth());
				editJob.setText(memberEdit.getM_job());
				editCharacter.setText(memberEdit.getM_character());
				editdpDate.setText(memberEdit.getM_register());
				editdpDateAnd.setText(memberEdit.getM_registerand());
				editRegiNo.setText(memberEdit.getM_regiNo());
				editTrainer.setText(memberEdit.getM_trainer());
				editType.setText(memberEdit.getM_type());
				editSessionPT.setText(memberEdit.getM_sessionPT());
				editSessionOT.setText(memberEdit.getM_sessionOT());
				editLevel.setText(memberEdit.getM_level());
				editRuntime.setText(memberEdit.getM_runtime());
				editRunday.setText(memberEdit.getM_runday());
				editRundate.setText(memberEdit.getM_rundate());
				editSmoking.setText(memberEdit.getM_smoking());
				editDrinking.setText(memberEdit.getM_drinking());
				editReason.setText(memberEdit.getM_reason());
				editMedical.setText(memberEdit.getM_medical());
				// editImage.setText(memberEdit.getM_image());
				Button btnMemberReEdit = (Button) parentEdit.lookup("#btnMemberReEdit");
				Button btnMemberReExit = (Button) parentEdit.lookup("#btnMemberReExit");
				// ����â ������ư
				System.out.println("����1");
				btnMemberReEdit.setOnAction(e -> {
					MemberVO mvo = new MemberVO();
					System.out.println("VO����");
					MemberDAO mDao = new MemberDAO();
					System.out.println("DAO����");
					try {
						System.out.println("111111");
						mvo = new MemberVO(Integer.parseInt(editNo.getText()), editName.getText(), editGender.getText(),
								editPhone.getText(), editAge.getText(), editBirth.getText(), editJob.getText(),
								editCharacter.getText(), editdpDate.getText(), editdpDateAnd.getText(),
								editRegiNo.getText(), editTrainer.getText(), editType.getText(),
								editSessionPT.getText(), editSessionOT.getText(), editLevel.getText(),
								editLevel.getText(), editRuntime.getText(), editRunday.getText(), editRundate.getText(),
								editSmoking.getText(), editDrinking.getText(), editReason.getText(),
								editMedical.getText());
						System.out.println("22222");
						mDao = new MemberDAO();
						System.out.println("33333");
						mDao.getMemberUpdate(mvo, mvo.getNo());
						System.out.println("44444");
						data.removeAll(data);
						System.out.println("55555");
						totalList();

					} catch (Exception e1) {
						System.out.println("����â ������ư" + e1);
					}

				});
				// ����â �������ư
				btnMemberReExit.setOnAction(e -> {
					EditDialog.close();
				});
				Scene scene = new Scene(parentEdit);
				EditDialog.setScene(scene);
				EditDialog.setResizable(false);
				EditDialog.show();
			}
		} catch (Exception e) {
			System.out.println("������ư����" + e);

		}

	}

}
