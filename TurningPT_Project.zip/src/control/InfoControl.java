package control;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.MemberVO;

public class InfoControl implements Initializable {
	@FXML
	private Button btnIfSave;
	@FXML
	private Button btnIfMember;
	@FXML
	private Button btnIfContract;
	@FXML
	private Button btnIfTrainerSave;
	@FXML
	private Button btnIfTrainer;
	@FXML
	private Button btnIfProduct;
	@FXML
	private Button btnIfBack;
	@FXML
	private Button btnIfTrainerList;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnIfBack.setOnAction(event -> handlerBtnIfBack(event)); // �ڷΰ��� ��ư
		btnIfProduct.setOnAction(event -> handlerBtnIfProduct(event)); // ��ǰ�� ��ư
		btnIfTrainerSave.setOnAction(event -> handlerBtnIfTrainerSave(event)); // Ʈ���̳ʵ�� ��ư
		btnIfSave.setOnAction(event -> handlerBtnIfSave(event)); // ȸ����� ��ư
		btnIfTrainerList.setOnAction(event -> handlerBtnIfTrainerList(event)); // Ʈ���̳ʸ�� ��ư

	}
	// Ʈ���̳� ������ ��� ��ư �޼ҵ�
	private void handlerBtnIfTrainerList(ActionEvent event) {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ProfileView.fxml"));
				Parent ProfileView = (Parent) loader.load();
				Scene scene = new Scene(ProfileView);
				Stage ProfileStage = new Stage();
				ProfileStage.setTitle("Ʈ���̳� ������");
				ProfileStage.setScene(scene);
				ProfileStage.setResizable(false);
				Stage oldStage = (Stage) btnIfTrainerList.getScene().getWindow();
				oldStage.close();
				ProfileStage.show();

			} catch (Exception e) {
				System.out.println("����" + e);

			}
		}
	

	// Ʈ���̳ʵ�� ��ư �޼ҵ�
	private void handlerBtnIfTrainerSave(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/TrainerView.fxml"));
			Parent MemberView = (Parent) loader.load();
			Scene scene = new Scene(MemberView);
			Stage MemberStage = new Stage();
			MemberStage.setTitle("Ʈ���̳� ���");
			MemberStage.setScene(scene);
			MemberStage.setResizable(false);
			Stage oldStage = (Stage) btnIfSave.getScene().getWindow();
			oldStage.close();
			MemberStage.show();

		} catch (Exception e) {
			System.out.println("����" + e);

		}

	}

	// ���α׷���� ��ư �޼ҵ�
	private void handlerBtnIfProduct(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ProductView.fxml"));
			Parent MemberView = (Parent) loader.load();
			Scene scene = new Scene(MemberView);
			Stage MemberStage = new Stage();
			MemberStage.setTitle("���α׷� ���");
			MemberStage.setScene(scene);
			MemberStage.setResizable(false);
			Stage oldStage = (Stage) btnIfSave.getScene().getWindow();
			oldStage.close();
			MemberStage.show();

		} catch (Exception e) {
			System.out.println("����" + e);

		}

	}

	// ȸ����Ϲ�ư �޼ҵ�
	private void handlerBtnIfSave(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MemberView.fxml"));
			Parent MemberView = (Parent) loader.load();
			Scene scene = new Scene(MemberView);
			Stage MemberStage = new Stage();
			MemberStage.setTitle("ȸ������ ���");
			MemberStage.setScene(scene);
			MemberStage.setResizable(false);
			Stage oldStage = (Stage) btnIfSave.getScene().getWindow();
			oldStage.close();
			MemberStage.show();

		} catch (Exception e) {
			System.out.println("����" + e);

		}

	}

	// �ڷΰ����ư �޼ҵ�
	private void handlerBtnIfBack(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/LoginView.fxml"));
			Parent loginView = (Parent) loader.load();
			Scene scane = new Scene(loginView);
			Stage mainStage = new Stage();
			mainStage.setTitle("�α���");
			mainStage.setScene(scane);
			mainStage.setResizable(false);

			Stage oldStage = (Stage) btnIfBack.getScene().getWindow();
			oldStage.close();
			mainStage.show();
		} catch (Exception e) {
			System.out.println("����" + e);
		}
	}
}
