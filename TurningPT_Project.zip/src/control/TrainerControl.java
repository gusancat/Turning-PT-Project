package control;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import dao.MemberDAO;
import dao.TrainerDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.FileChooser.ExtensionFilter;
import model.MemberVO;
import model.TrainerVO;

public class TrainerControl implements Initializable {
	@FXML
	private TextField txtTrainerName; // �̸�
	@FXML
	private TextField txtTrainerAge; // ����
	@FXML
	private TextField txtTrainerPhone; // ��ȭ��ȣ
	@FXML
	private TextField txtTrainerNo; // �������ѹ�
	@FXML
	private TextField txtTrainerJob; // ��å
	@FXML
	private TextField txtTrainerBirth; // ����
	@FXML
	private TextField txtTrainerAdress; // �ּ�
	@FXML
	private TextField txtExp1; // ��»���1
	@FXML
	private TextField txtExp2; // ��»���2
	@FXML
	private TextField txtExp3; // ��»���3
	@FXML
	private TextField txtExp4; // ��»���4
	@FXML
	private TextField txtExp5; // ��»���5
	@FXML
	private TextField txtExp6; // ��»���6
	@FXML
	private TextField txtExp7; // ��»���7
	@FXML
	private TextField txtExp8; // ��»���8
	@FXML
	private TextField txtExp9; // ��»���9
	@FXML
	private ToggleGroup runtimeGroup;
	@FXML
	private ToggleGroup genderGroup;
	@FXML
	private RadioButton rbMoning;
	@FXML
	private RadioButton rbAfternoon;
	@FXML
	private RadioButton rbEvenning;
	@FXML
	private RadioButton rbMale;
	@FXML
	private RadioButton rbFemale;
	@FXML
	private ComboBox<String> cbProgram1;
	@FXML
	private ComboBox<String> cbProgram2;
	@FXML
	private DatePicker dpTDate;
	@FXML
	private DatePicker dpTAndDate;
	@FXML
	private ImageView imageViewTrainer;
	@FXML
	private TextField txtTrainerSearch;
	@FXML
	private Button btnTrainerSave; // �����ư
	@FXML
	private Button btnTrainerEdit; // ������ư
	@FXML
	private Button btnTrainerDelete; // ������ư
	@FXML
	private Button btnTrainerExit; // �������ư
	@FXML
	private Button btnTrainerSearch; // �˻���ư
	@FXML
	private Button btnTrainerImageAdd; // �̹����߰���ư
	@FXML
	private Button btnTrainerTotal; // Ʈ���̳� ��ü�ҷ����� ��ư
	@FXML
	private TableView<TrainerVO> tableViewTrainer = new TableView<>();
	@FXML
	private TextField txtTrainerNoEdit;
	@FXML
	private TextField txtTrainerNameEdit;
	@FXML
	private TextField txtTrainerAgeEdit;
	@FXML
	private TextField txtTrainerPhoneEdit;
	@FXML
	private TextField txtTrainerRuntimeEdit;
	@FXML
	private TextField txtTrainerGenderEdit;
	@FXML
	private TextField txtTrainerBirthEdit;
	@FXML
	private TextField txtTrainerAdressEdit;
	@FXML
	private TextField txtTrainerJobEdit;
	@FXML
	private TextField txtTrainerProgramEdit1;
	@FXML
	private TextField txtTrainerProgramEdit2;
	@FXML
	private TextField txtTrainerdpDateEdit;
	@FXML
	private TextField txtTrainerdpDateAndEdit;
	@FXML
	private TextField txtExp1Edit;
	@FXML
	private TextField txtExp2Edit;
	@FXML
	private TextField txtExp3Edit;
	@FXML
	private TextField txtExp4Edit;
	@FXML
	private TextField txtExp5Edit;
	@FXML
	private TextField txtExp6Edit;
	@FXML
	private TextField txtExp7Edit;
	@FXML
	private TextField txtExp8Edit;
	@FXML
	private TextField txtExp9Edit;
	@FXML
	private Button btnTrainerReEdit;
	@FXML
	private Button btnTrainerReExit;
	@FXML
	private TextField txtTrainerdpDateInfo;
	@FXML
	private TextField txtTrainerdpDateAndInfo;

	ObservableList<TrainerVO> data = FXCollections.observableArrayList();
	ObservableList<TrainerVO> selectTrainer = null; // ���̺����� ������ ���� ����

	int selectedIndex; // ���̺����� ������ �л����� �ε��� ����

	boolean editDelete = false; // Ȯ�� ��ư ���� ����
	TrainerVO trainerVO = new TrainerVO();
	private Stage primaryStage;

	String SelectFileName = ""; // �̹��� ���ϸ�
	String localUrl = ""; // �̹��� ���ϰ��
	Image localImage;
	int no; // ������ ���̺����� ������ �л��� ��ȣ ����
	File selectedFile = null;

	// �̹��� ó��
	private File dirSave = new File("C:/images"); // �̹��� ������ ������ �Ű������� ���� ��ü ����
	private File file = null; // �̹��� �ҷ��� ������ ������ ���� ��ü ����

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		dpTDate.setValue(LocalDate.now());
		btnTrainerSave.setOnAction(event -> handlerBtnTrainerSave(event)); // �����ư
		btnTrainerEdit.setOnAction(event -> handlerBtnTrainerEdit(event)); // ������ư
		btnTrainerDelete.setOnAction(event -> handlerBtnTrainerDelete(event)); // ������ư
		btnTrainerExit.setOnAction(event -> handlerBtnTrainerExit(event)); // �������ư
		btnTrainerSearch.setOnAction(event -> handlerBtnTrainerSearch(event)); // �˻���ư
		btnTrainerImageAdd.setOnAction(event -> handlerBtnTrainerImageAdd(event));// �̹����߰���ư
		btnTrainerTotal.setOnAction(event -> handlerBtnTrainerTotal(event)); // ��ü �ҷ����� ��ư
		txtTrainerSearch.setOnKeyPressed(event -> enterTrainerSearch(event)); // �˻� text ���� ����Ű ������ �˻���ư Ȱ��ȭ
		tableViewTrainer.setOnMouseClicked(event -> handlerClickInfomation(event)); // ����Ŭ������ Ʈ���̳�����â �ҷ���

		cbProgram1.setItems(FXCollections.observableArrayList("PT", "OT", "�׷�PT", "�䰡", "�ö��׿䰡", "����", "�ʶ��׽�", "���Ǵ�",
				"����", "��쳪", "����"));
		cbProgram2.setItems(FXCollections.observableArrayList("PT", "OT", "�׷�PT", "�䰡", "�ö��׿䰡", "����", "�ʶ��׽�", "���Ǵ�",
				"����", "��쳪", "����"));

		TableColumn colNo = new TableColumn("NO.");
		colNo.setMinWidth(40);
		colNo.setStyle("-fx-allignment: CENTER");
		colNo.setCellValueFactory(new PropertyValueFactory<>("no"));

		TableColumn colName = new TableColumn("�̸�");
		colName.setMinWidth(80);
		colName.setCellValueFactory(new PropertyValueFactory<>("t_name"));

		TableColumn colAge = new TableColumn("����");
		colAge.setMinWidth(40);
		colAge.setCellValueFactory(new PropertyValueFactory<>("t_age"));

		TableColumn colGender = new TableColumn("����");
		colGender.setMinWidth(30);
		colGender.setCellValueFactory(new PropertyValueFactory<>("t_gender"));

		TableColumn colBirth = new TableColumn("����");
		colBirth.setMinWidth(80);
		colBirth.setCellValueFactory(new PropertyValueFactory<>("t_birth"));

		TableColumn colPhone = new TableColumn("��ȭ��ȣ");
		colPhone.setMinWidth(80);
		colPhone.setCellValueFactory(new PropertyValueFactory<>("t_phone"));

		TableColumn colRuntime = new TableColumn("�ٹ��ð�");
		colRuntime.setMinWidth(80);
		colRuntime.setCellValueFactory(new PropertyValueFactory<>("t_runtime"));

		TableColumn colAdress = new TableColumn("�ּ�");
		colAdress.setMinWidth(80);
		colAdress.setCellValueFactory(new PropertyValueFactory<>("t_adress"));

		TableColumn colJob = new TableColumn("��å");
		colJob.setMinWidth(80);
		colJob.setCellValueFactory(new PropertyValueFactory<>("t_job"));

		TableColumn coldpDate = new TableColumn("�Ի���");
		coldpDate.setMinWidth(40);
		coldpDate.setCellValueFactory(new PropertyValueFactory<>("t_dpdate"));

		TableColumn coldpAndDate = new TableColumn("�����");
		coldpAndDate.setMinWidth(40);
		coldpAndDate.setCellValueFactory(new PropertyValueFactory<>("t_dpanddate"));

		TableColumn colProgram1 = new TableColumn("���α׷�1");
		colProgram1.setMinWidth(40);
		colProgram1.setCellValueFactory(new PropertyValueFactory<>("t_program1"));

		TableColumn colProgram2 = new TableColumn("���α׷�2");
		colProgram2.setMinWidth(40);
		colProgram2.setCellValueFactory(new PropertyValueFactory<>("t_program2"));

		TableColumn colExp1 = new TableColumn("��»���1");
		colExp1.setMinWidth(40);
		colExp1.setCellValueFactory(new PropertyValueFactory<>("t_exp1"));

		TableColumn colExp2 = new TableColumn("��»���2");
		colExp2.setMinWidth(40);
		colExp2.setCellValueFactory(new PropertyValueFactory<>("t_exp2"));

		TableColumn colExp3 = new TableColumn("��»���3");
		colExp3.setMinWidth(40);
		colExp3.setCellValueFactory(new PropertyValueFactory<>("t_exp3"));

		TableColumn colExp4 = new TableColumn("��»���4");
		colExp4.setMinWidth(40);
		colExp4.setCellValueFactory(new PropertyValueFactory<>("t_exp4"));

		TableColumn colExp5 = new TableColumn("��»���5");
		colExp5.setMinWidth(40);
		colExp5.setCellValueFactory(new PropertyValueFactory<>("t_exp5"));

		TableColumn colExp6 = new TableColumn("��»���6");
		colExp6.setMinWidth(40);
		colExp6.setCellValueFactory(new PropertyValueFactory<>("t_exp6"));

		TableColumn colExp7 = new TableColumn("��»���7");
		colExp7.setMinWidth(40);
		colExp7.setCellValueFactory(new PropertyValueFactory<>("t_exp7"));

		TableColumn colExp8 = new TableColumn("��»���8");
		colExp8.setMinWidth(40);
		colExp8.setCellValueFactory(new PropertyValueFactory<>("t_exp8"));

		TableColumn colExp9 = new TableColumn("��»���9");
		colExp9.setMinWidth(40);
		colExp9.setCellValueFactory(new PropertyValueFactory<>("t_exp9"));

		TableColumn colImage = new TableColumn("�̹���");
		colImage.setMinWidth(60);
		colImage.setCellValueFactory(new PropertyValueFactory<>("t_image"));

		tableViewTrainer.setItems(data);
		tableViewTrainer.getColumns().addAll(colNo, colName, colAge, colGender, colBirth, colPhone, colAdress,
				colRuntime, colJob, coldpDate, coldpAndDate, colProgram1, colProgram2, colExp1, colExp2, colExp3,
				colExp4, colExp5, colExp6, colExp7, colExp8, colExp9, colImage);

		// ȸ�� ��ü ����
		totalList();

		// �⺻ �̹���
		localUrl = "/image/default.png";
		localImage = new Image(localUrl, false);
		imageViewTrainer.setImage(localImage);
	}

	// ���콺 Ŭ���ϸ� ����â ���
	private void handlerClickInfomation(MouseEvent event) {
		TrainerVO InfoVO = tableViewTrainer.getSelectionModel().getSelectedItem();
		selectedIndex = tableViewTrainer.getSelectionModel().getSelectedIndex();
		// String image =
		// tableViewTrainer.getSelectionModel().getSelectedItem().getT_image();
		// tableViewTrainer.getSelectionModel().getSelectedItem().getT_image();

		if (event.getClickCount() != 2) {
			try {
				selectTrainer = tableViewTrainer.getSelectionModel().getSelectedItems();
				no = selectTrainer.get(0).getNo();
			} catch (Exception e) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ȸ������");
				alert.setHeaderText("ȸ�������� �����ϴ�.");
				alert.setContentText("ȸ�� ������ �Է��� �Ŀ� �����ϼ���");
				alert.showAndWait();
			}
			return;
		}
		try {
			Stage infoDialog = new Stage(StageStyle.UTILITY);
			infoDialog.initModality(Modality.WINDOW_MODAL);
			infoDialog.setTitle("Ʈ���̳� ����");

			Parent parentInfo = FXMLLoader.load(getClass().getResource("/view/TrainerInfomation.fxml"));
			Scene scene = new Scene(parentInfo);
			infoDialog.setScene(scene);
			infoDialog.show();
			if (InfoVO != null) {
				//ImageView infoImage = (ImageView) parentInfo.lookup("#imageViewTrainer");
				TextField infoNo = (TextField) parentInfo.lookup("#txtTrainerNoInfo"); // 1 �������ѹ�
				TextField infoName = (TextField) parentInfo.lookup("#txtTrainerNameInfo"); // 2 �̸�
				TextField infoAge = (TextField) parentInfo.lookup("#txtTrainerAgeInfo"); // 3 ����
				TextField infoGender = (TextField) parentInfo.lookup("#txtTrainerGenderInfo"); // 4 ����
				TextField infoBirth = (TextField) parentInfo.lookup("#txtTrainerBirthInfo"); // 6 �������
				TextField infoPhone = (TextField) parentInfo.lookup("#txtTrainerPhoneInfo"); // 5 ��ȭ��ȣ
				TextField infoAdress = (TextField) parentInfo.lookup("#txtTrainerAdressInfo"); // 8 �ּ�
				TextField infoRuntime = (TextField) parentInfo.lookup("#txtTrainerRuntimeInfo"); // 7 �ٹ��ð�
				TextField infoJob = (TextField) parentInfo.lookup("#txtTrainerJobInfo"); // 9 ��å
				TextField infodpDate = (TextField) parentInfo.lookup("#txtTrainerdpDateInfo"); // 11 �Ի���
				TextField infodpDateAnd = (TextField) parentInfo.lookup("#txtTrainerdpDateAndInfo");// 12 �����
				TextField infoProgram1 = (TextField) parentInfo.lookup("#txtTrainerProgram1Info"); // 10 ������α׷�
				TextField infoProgram2 = (TextField) parentInfo.lookup("#txtTrainerProgram2Info"); // 10 ������α׷�
				TextField infoExp1 = (TextField) parentInfo.lookup("#txtExp1Info"); // 13
				TextField infoExp2 = (TextField) parentInfo.lookup("#txtExp2Info"); // 14
				TextField infoExp3 = (TextField) parentInfo.lookup("#txtExp3Info"); // 15
				TextField infoExp4 = (TextField) parentInfo.lookup("#txtExp4Info"); // 16
				TextField infoExp5 = (TextField) parentInfo.lookup("#txtExp5Info"); // 17
				TextField infoExp6 = (TextField) parentInfo.lookup("#txtExp6Info"); // 18
				TextField infoExp7 = (TextField) parentInfo.lookup("#txtExp7Info"); // 19
				TextField infoExp8 = (TextField) parentInfo.lookup("#txtExp8Info"); // 20
				TextField infoExp9 = (TextField) parentInfo.lookup("#txtExp9Info"); // 21
				System.out.println("����Ŭ��1");

				infoNo.setDisable(true);
				infoName.setDisable(true); // 1
				infoAge.setDisable(true); // 2
				infoGender.setDisable(true); // 3
				infoBirth.setDisable(true); // 5
				infoPhone.setDisable(true); // 4
				infoAdress.setDisable(true); // 7
				infoRuntime.setDisable(true); // 6
				infoJob.setDisable(true); // 8
				infodpDate.setDisable(true); // 10
				infodpDateAnd.setDisable(true);
				infoProgram1.setDisable(true); // 9
				infoProgram2.setDisable(true);
				infoExp1.setDisable(true); // 11
				infoExp2.setDisable(true); // 12
				infoExp3.setDisable(true); // 13
				infoExp4.setDisable(true); // 14
				infoExp5.setDisable(true); // 15
				infoExp6.setDisable(true); // 16
				infoExp7.setDisable(true); // 17
				infoExp8.setDisable(true); // 18
				infoExp9.setDisable(true); // 19

				infoNo.setText(InfoVO.getNo() + ""); // 1
				infoName.setText(InfoVO.getT_name());
				infoAge.setText(InfoVO.getT_age()); // 2
				infoGender.setText(InfoVO.getT_gender()); // 3
				infoBirth.setText(InfoVO.getT_birth());
				infoPhone.setText(InfoVO.getT_phone()); // 4
				infoAdress.setText(InfoVO.getT_adress()); // 7
				infoRuntime.setText(InfoVO.getT_runtime()); // 6
				infoJob.setText(InfoVO.getT_job()); // 8
				infodpDate.setText(InfoVO.getT_dpdate()); // 10
				infodpDateAnd.setText(InfoVO.getT_dpanddate());
				infoProgram1.setText(InfoVO.getT_program1());// 9
				infoProgram2.setText(InfoVO.getT_program2());
				infoExp1.setText(InfoVO.getT_exp1()); // 11
				infoExp2.setText(InfoVO.getT_exp2()); // 12
				infoExp3.setText(InfoVO.getT_exp3()); // 13
				infoExp4.setText(InfoVO.getT_exp4()); // 14
				infoExp5.setText(InfoVO.getT_exp5()); // 15
				infoExp6.setText(InfoVO.getT_exp6()); // 16
				infoExp7.setText(InfoVO.getT_exp7()); // 17
				infoExp8.setText(InfoVO.getT_exp8()); // 18
				infoExp9.setText(InfoVO.getT_exp9()); // 19

				Button btnTrainerInfoExit = (Button) parentInfo.lookup("#btnTrainerInfoExit");

				btnTrainerInfoExit.setOnAction(e -> {
					infoDialog.close();
				});

				totalList();

				localUrl = "/image/default.png";
				localImage = new Image(localUrl, false);
				//infoImage.setImage(localImage);

			}

		} catch (Exception e) {
			System.out.println("����Ŭ��" + e);
		}
	}

	// ������ư �޼ҵ�
	private void handlerBtnTrainerEdit(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/view/TrainerEdit.fxml"));
			Stage EditDialog = new Stage(StageStyle.UTILITY);
			EditDialog.initModality(Modality.WINDOW_MODAL);
			EditDialog.initOwner(btnTrainerEdit.getScene().getWindow());
			EditDialog.setTitle("Ʈ���̳� ���� ����â");
			Parent parentEdit = (Parent) loader.load();
			TrainerVO TrainerEdit = tableViewTrainer.getSelectionModel().getSelectedItem();
			selectedIndex = tableViewTrainer.getSelectionModel().getSelectedIndex();
			String imgpath = tableViewTrainer.getSelectionModel().getSelectedItem().getT_image();

			// VO ���� ������ �̸��� #���� �ҷ��ͼ� edit �� �������
			if (TrainerEdit != null) {
				TextField editNo = (TextField) parentEdit.lookup("#txtTrainerNoEdit");
				TextField editName = (TextField) parentEdit.lookup("#txtTrainerNameEdit"); // 1 �̸�
				TextField editAge = (TextField) parentEdit.lookup("#txtTrainerAgeEdit"); // 2 ����
				TextField editGender = (TextField) parentEdit.lookup("#txtTrainerGenderEdit"); // 3 ����
				TextField editPhone = (TextField) parentEdit.lookup("#txtTrainerPhoneEdit"); // 4 ��ȭ��ȣ
				TextField editBirth = (TextField) parentEdit.lookup("#txtTrainerBirthEdit"); // 5 �������
				TextField editRuntime = (TextField) parentEdit.lookup("#txtTrainerRuntimeEdit"); // 6 �ٹ��ð�
				TextField editAdress = (TextField) parentEdit.lookup("#txtTrainerAdressEdit"); // 7 �ּ�
				TextField editJob = (TextField) parentEdit.lookup("#txtTrainerJobEdit"); // 8 ��å
				TextField editdpDate = (TextField) parentEdit.lookup("#txtTrainerdpDateEdit"); // 10 �Ի���
				TextField editdpDateAnd = (TextField) parentEdit.lookup("#txtTrainerdpDateAndEdit");// 11 �����
				TextField editProgram1 = (TextField) parentEdit.lookup("#txtTrainerProgramEdit1"); // 9 ������α׷�
				TextField editProgram2 = (TextField) parentEdit.lookup("#txtTrainerProgramEdit2");
				TextField editExp1 = (TextField) parentEdit.lookup("#txtExp1Edit"); // 12
				TextField editExp2 = (TextField) parentEdit.lookup("#txtExp2Edit"); // 13
				TextField editExp3 = (TextField) parentEdit.lookup("#txtExp3Edit"); // 14
				TextField editExp4 = (TextField) parentEdit.lookup("#txtExp4Edit"); // 15
				TextField editExp5 = (TextField) parentEdit.lookup("#txtExp5Edit"); // 16
				TextField editExp6 = (TextField) parentEdit.lookup("#txtExp6Edit"); // 17
				TextField editExp7 = (TextField) parentEdit.lookup("#txtExp7Edit"); // 18
				TextField editExp8 = (TextField) parentEdit.lookup("#txtExp8Edit"); // 19
				TextField editExp9 = (TextField) parentEdit.lookup("#txtExp9Edit"); // 20
				// TextField editImage = (TextField) parentEdit.lookup("#txteditImage");

				editName.setText(TrainerEdit.getT_name());
				editAge.setText(TrainerEdit.getT_age()); // 1
				editGender.setText(TrainerEdit.getT_gender()); // 2
				editBirth.setText(TrainerEdit.getT_birth()); // 4
				editPhone.setText(TrainerEdit.getT_phone()); // 3
				editAdress.setText(TrainerEdit.getT_adress()); // 9
				editRuntime.setText(TrainerEdit.getT_runtime()); // 8
				editJob.setText(TrainerEdit.getT_job()); // 5
				editdpDate.setText(TrainerEdit.getT_dpdate()); // 6
				editdpDateAnd.setText(TrainerEdit.getT_dpanddate());// 7
				editProgram1.setText(TrainerEdit.getT_program1()); // 10
				editProgram2.setText(TrainerEdit.getT_program2());
				editExp1.setText(TrainerEdit.getT_exp1()); // 11
				editExp2.setText(TrainerEdit.getT_exp2()); // 12
				editExp3.setText(TrainerEdit.getT_exp3()); // 13
				editExp4.setText(TrainerEdit.getT_exp4()); // 14
				editExp5.setText(TrainerEdit.getT_exp5()); // 15
				editExp6.setText(TrainerEdit.getT_exp6()); // 16
				editExp7.setText(TrainerEdit.getT_exp7()); // 17
				editExp8.setText(TrainerEdit.getT_exp8()); // 18
				editExp9.setText(TrainerEdit.getT_exp9()); // 19
				// editImage.setText(memberEdit.getM_image());
				Button btnTrainerReEdit = (Button) parentEdit.lookup("#btnTrainerReEdit");
				Button btnTrainerReExit = (Button) parentEdit.lookup("#btnTrainerReExit");
				// ����â ������ư

				btnTrainerReEdit.setOnAction(e -> {
					TrainerVO tvo = new TrainerVO();
					TrainerDAO tDao = new TrainerDAO();
					try {
						tvo = new TrainerVO(editNo.getText(), editName.getText(), editAge.getText(), editGender.getText(), editBirth.getText(), editPhone.getText(),  editAdress.getText(), editRuntime.getText(),
								editJob.getText(), editdpDate.getText(), editdpDateAnd.getText(), editProgram1.getText(), editProgram2.getText(), 
								editExp1.getText(), editExp2.getText(), editExp3.getText(), editExp4.getText(), editExp5.getText(), editExp6.getText(), editExp7.getText(), editExp8.getText(), editExp9.getText());

						tDao = new TrainerDAO();
						tDao.getTrainerUpdate(tvo, tvo.getNo());
						data.removeAll(data);
						totalList();

					} catch (Exception e1) {
						System.out.println("����â ������ư" + e1);
					}
					EditDialog.close();
				});
				// ����â �������ư
				btnTrainerReExit.setOnAction(e -> {
					EditDialog.close();
				});
				Scene scene = new Scene(parentEdit);
				EditDialog.setScene(scene);
				EditDialog.setResizable(false);
				EditDialog.show();
			}
		} catch (Exception e) {
			System.out.println("������ư����" + e);
		}
	}

	// ��ü�ҷ����� ��ư �޼ҵ�
	private void handlerBtnTrainerTotal(ActionEvent event) {
		try {
			data.removeAll(data);
			totalList();
		} catch (Exception e) {
		}
	}

	// �˻� text���� ���ʹ����� Ȱ��ȭ
	private void enterTrainerSearch(KeyEvent event) {
		if (event.getCode() == KeyCode.ENTER) {
			Search();
		}

	}

	// �˻� �޼ҵ�
	public void Search() {
		TrainerVO tVo = new TrainerVO();
		TrainerDAO tDao = null;
		Object[][] totalData = null;
		String searchName = "";
		boolean searchResult = false;

		try {
			searchName = txtTrainerSearch.getText().trim();
			tDao = new TrainerDAO();
			tVo = tDao.getTrainerCheck(searchName);
			if (searchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ������ �˻�");
				alert.setHeaderText("ȸ���̸��� �Է����ּ���");
				alert.setContentText("�ٽ� �Է����ּ���");
				alert.showAndWait();
			}
			if (!searchName.equals("") && (tVo != null)) {
				ArrayList<String> title;
				ArrayList<TrainerVO> list;

				title = tDao.getColumnName();
				int columCount = title.size();

				list = tDao.getTrainetTotalList(); /////
				int rowCount = list.size();

				totalData = new Object[rowCount][columCount];

				if (tVo.getT_name().equals(searchName)) {

					// txtMemberSearch.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						tVo = list.get(index);
						if (tVo.getT_name().equals(searchName)) {
							data.add(tVo);
							searchResult = true;
						}
					}
				}
			}

			if (!searchResult) {
				System.out.println(searchName);
				txtTrainerSearch.clear();
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ������ �˻�");
				alert.setHeaderText(searchName + "ȸ���� ����Ʈ�� �����ϴ�.");
				alert.setContentText("�ٽ� �˻��ϼ���");
				alert.showAndWait();

			}
		} catch (Exception e) {
			System.out.println("�˻���ư����" + e);
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("ȸ������ �˻�����");
			alert.setHeaderText(searchName + "ȸ������ �˻��� ������ �߻��Ͽ����ϴ�.");
			alert.setContentText("�ٽ� �ϼ���");
			alert.showAndWait();
		}
	}

	// �˻���ư �޼ҵ�
	private void handlerBtnTrainerSearch(ActionEvent event) {
		Search();
	}

	// ������ư �޼ҵ�
	private void handlerBtnTrainerDelete(ActionEvent event) {
		TrainerDAO mDao = null;
		mDao = new TrainerDAO();

		try {
			mDao.getTrainerDelete(tableViewTrainer.getSelectionModel().getSelectedItem().getNo());
			data.removeAll(data);
			totalList();

		} catch (Exception e) {
			System.out.println("Ʈ���̳ʻ���" + e);
		}
	}


	// Ʈ���̳����� ��Ϲ�ư �޼ҵ�
	private void handlerBtnTrainerSave(ActionEvent event) {
		TrainerVO trainerVO = null;
		TrainerDAO trainerDAO = null;
		data.removeAll(data);
		File dirMake = new File(dirSave.getAbsolutePath());

		// �̹��� ���� ���� ����
		if (!dirMake.exists()) {
			dirMake.mkdir();
		}

		// �̹��� �������� �޼ҵ�
		String fileName = imageSave(selectedFile);

		try {

			trainerVO = new TrainerVO(txtTrainerName.getText(), txtTrainerAge.getText(), genderGroup.getSelectedToggle().getUserData().toString(), txtTrainerBirth.getText(), txtTrainerPhone.getText(),
					txtTrainerAdress.getText(), runtimeGroup.getSelectedToggle().getUserData().toString(), txtTrainerJob.getText(), dpTDate.getValue().toString(), dpTAndDate.getValue().toString(),
					cbProgram1.getSelectionModel().getSelectedItem(), cbProgram2.getSelectionModel().getSelectedItem(),
					txtExp1.getText(), txtExp2.getText(), txtExp3.getText(), txtExp4.getText(), txtExp5.getText(),
					txtExp6.getText(), txtExp7.getText(), txtExp8.getText(), txtExp9.getText(),
					imageViewTrainer.getImage().toString());

			trainerDAO = new TrainerDAO();
			trainerDAO.getTrainerSave(trainerVO);

			totalList();

			if (trainerDAO != null) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ���������");
				alert.setHeaderText("ȸ��������� ���强��");
				alert.setContentText("������ ����Ǿ����ϴ�.");
				alert.setResizable(false);
				alert.showAndWait();
			}

		} catch (Exception e) {
			System.out.println("�̹������� ���� ����" + e);
		}
	}

	// �̹��� ���� �޼ҵ�
	public boolean imageDelete(String fileName) {
		boolean result = false;
		try {
			File fileDelete = new File(dirSave.getAbsolutePath() + "\\" + fileName); // �����̹��� ����
			if (fileDelete.exists() && fileDelete.isFile()) {
				result = fileDelete.delete();
				// �⺻ �̹���
				localUrl = "/image/default.png";
				localImage = new Image(localUrl, false);
				imageViewTrainer.setImage(localImage);
			}
		} catch (Exception e) {
			System.out.println("�̹��� ���� ����" + e);
			result = false;
		}
		return result;
	}

	// �̹��� ���� �޼ҵ�
	public String imageSave(File file) {
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;

		int data = -1;
		String fileName = null;
		try {
			// �̹��� ���ϻ���
			fileName = "trainer" + System.currentTimeMillis() + "_" + file.getName();
			bis = new BufferedInputStream(new FileInputStream(file));
			bos = new BufferedOutputStream(new FileOutputStream(dirSave.getAbsolutePath() + "\\" + fileName));
			// ������ �̹��� ���� InputStream �� �������� �̸����� ���� -1
			while ((data = bis.read()) != -1) {
				bos.write(data);
				bos.flush();
			}
		} catch (Exception e) {
			e.getMessage();
		} finally {
			try {
				if (bos != null) {
					bos.close();
				}
				if (bis != null) {
					bis.close();
				}
			} catch (IOException e) {

			}
		}
		return fileName;

	}

	// �̹����߰� ��ư �޼ҵ�
	private void handlerBtnTrainerImageAdd(ActionEvent event) {
		FileChooser fileChooser = new FileChooser();
		fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Image File", "*.png", "*.jpg", "*.gif"));
		try {
			selectedFile = fileChooser.showOpenDialog(primaryStage);
			if (selectedFile != null) {
				// �̹��� ���� ���
				localUrl = selectedFile.toURI().toURL().toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		localImage = new Image(localUrl, false);
		imageViewTrainer.setImage(localImage);
		imageViewTrainer.setFitHeight(250);
		imageViewTrainer.setFitWidth(230);
		btnTrainerSave.setDisable(false);

		if (selectedFile != null) {
			SelectFileName = selectedFile.getName();
		}

	}

	// �������ư �޼ҵ�
	private void handlerBtnTrainerExit(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/InfoView.fxml"));
			Parent InfoView = (Parent) loader.load();
			Scene scane = new Scene(InfoView);
			Stage mainStage = new Stage();
			mainStage.setTitle("�ｺ�� �λ����");
			mainStage.setScene(scane);
			mainStage.setResizable(false);

			Stage oldStage = (Stage) btnTrainerExit.getScene().getWindow();
			oldStage.close();
			mainStage.show();
		} catch (Exception e) {
			System.out.println("�ڷΰ����ư ����" + e);
			e.getStackTrace();
		}
	}

	// ȸ�� ��ü ����Ʈ
	public void totalList() {
		Object[][] totalData;

		TrainerDAO tDao = new TrainerDAO();
		TrainerVO tVo = new TrainerVO();
		ArrayList<String> title;
		ArrayList<TrainerVO> list;

		title = tDao.getColumnName();
		int columnCount = title.size();

		list = tDao.getTrainetTotalList();
		int rowCount = list.size();
		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			tVo = list.get(index);
			data.add(tVo);
		}
	}

}
