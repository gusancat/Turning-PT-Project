package model;

/**
 * @author ParkWooRam
 *
 */
public class ProductVO {
	private int no; // ������ ��ȣ
	private String p_membername; // ȸ���̸�
	private String p_program; // ������α׷�
	private String p_productjoin; // ��ϱⰣ
	private String p_monthpay; // �� ���� �ݾ�
	private String p_productmax; // �ִ��ο�
	private String p_productlesson; // �����ο�
	private String p_register; // �������

	public ProductVO() {
	}

	public ProductVO(String p_membername, String p_program, String p_productjoin, String p_monthpay,
			String p_productmax, String p_productlesson, String p_register) {
		super();
		this.p_membername = p_membername;
		this.p_program = p_program;
		this.p_productjoin = p_productjoin;
		this.p_monthpay = p_monthpay;
		this.p_productmax = p_productmax;
		this.p_productlesson = p_productlesson;
		this.p_register = p_register;
	}

	public ProductVO(int no, String p_membername, String p_program, String p_productjoin, String p_monthpay,
			String p_productmax, String p_productlesson) {
		super();
		this.no = no;
		this.p_membername = p_membername;
		this.p_program = p_program;
		this.p_productjoin = p_productjoin;
		this.p_monthpay = p_monthpay;
		this.p_productmax = p_productmax;
		this.p_productlesson = p_productlesson;
	}

	public ProductVO(String p_membername, String p_program, String p_productjoin, String p_monthpay,
			String p_productmax, String p_productlesson) {
		super();
		this.p_membername = p_membername;
		this.p_program = p_program;
		this.p_productjoin = p_productjoin;
		this.p_monthpay = p_monthpay;
		this.p_productmax = p_productmax;
		this.p_productlesson = p_productlesson;
	}

	public ProductVO(int no, String p_membername, String p_program, String p_productjoin, String p_monthpay,
			String p_productmax, String p_productlesson, String p_register) {
		super();
		this.no = no;
		this.p_membername = p_membername;
		this.p_program = p_program;
		this.p_productjoin = p_productjoin;
		this.p_monthpay = p_monthpay;
		this.p_productmax = p_productmax;
		this.p_productlesson = p_productlesson;
		this.p_register = p_register;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getP_membername() {
		return p_membername;
	}

	public void setP_membername(String p_membername) {
		this.p_membername = p_membername;
	}

	public String getP_program() {
		return p_program;
	}

	public void setP_program(String p_program) {
		this.p_program = p_program;
	}

	public String getP_productjoin() {
		return p_productjoin;
	}

	public void setP_productjoin(String p_productjoin) {
		this.p_productjoin = p_productjoin;
	}

	public String getP_monthpay() {
		return p_monthpay;
	}

	public void setP_monthpay(String p_monthpay) {
		this.p_monthpay = p_monthpay;
	}

	public String getP_productmax() {
		return p_productmax;
	}

	public void setP_productmax(String p_productmax) {
		this.p_productmax = p_productmax;
	}

	public String getP_productlesson() {
		return p_productlesson;
	}

	public void setP_productlesson(String p_productlesson) {
		this.p_productlesson = p_productlesson;
	}

	public String getP_register() {
		return p_register;
	}

	public void setP_register(String p_register) {
		this.p_register = p_register;
	}

}
