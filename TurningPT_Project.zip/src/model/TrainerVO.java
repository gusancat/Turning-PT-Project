package model;

public class TrainerVO {
	private int no; 			// 1 ��������ȣ
	private String t_name;		// 2 �̸�
	private String t_age; 		// 3 ����
	private String t_gender; 	// 4 ����
	private String t_birth; 	// 5 �������
	private String t_phone; 	// 6 ��ȭ��ȣ
	private String t_adress; 	// 7 �ּ�
	private String t_runtime; 	// 8 �ٹ��ð�
	private String t_job; 		// 9 ��å
	private String t_dpdate; 	// 11 �Ի�����
	private String t_dpanddate; // 12 �������
	private String t_program1;  // 13 ������1
	private String t_program2;  // 14 ������2
	private String t_exp1; 		// 15 ��»���1
	private String t_exp2; 		// 16 ��»���2
	private String t_exp3; 		// 17 ��»���3
	private String t_exp4; 		// 18 ��»���4
	private String t_exp5; 		// 19 ��»���5
	private String t_exp6; 		// 20 ��»���6
	private String t_exp7; 		// 21 ��»���7
	private String t_exp8; 		// 22 ��»���8
	private String t_exp9; 		// 23 ��»���9
	private String t_image; 	// 10 �̹���

	public TrainerVO() {
	}

	public TrainerVO(String t_name, String t_age, String t_gender, String t_birth, String t_phone, String t_adress,
			String t_runtime, String t_job, String t_dpdate, String t_dpanddate, String t_program1, String t_program2,
			String t_exp1, String t_exp2, String t_exp3, String t_exp4, String t_exp5, String t_exp6, String t_exp7,
			String t_exp8, String t_exp9, String t_image) {
		super();
		this.t_name = t_name;
		this.t_age = t_age;
		this.t_gender = t_gender;
		this.t_birth = t_birth;
		this.t_phone = t_phone;
		this.t_adress = t_adress;
		this.t_runtime = t_runtime;
		this.t_job = t_job;
		this.t_dpdate = t_dpdate;
		this.t_dpanddate = t_dpanddate;
		this.t_program1 = t_program1;
		this.t_program2 = t_program2;
		this.t_exp1 = t_exp1;
		this.t_exp2 = t_exp2;
		this.t_exp3 = t_exp3;
		this.t_exp4 = t_exp4;
		this.t_exp5 = t_exp5;
		this.t_exp6 = t_exp6;
		this.t_exp7 = t_exp7;
		this.t_exp8 = t_exp8;
		this.t_exp9 = t_exp9;
		this.t_image = t_image;
	}

	public TrainerVO(int no, String t_name, String t_age, String t_gender, String t_birth, String t_phone,
			String t_adress, String t_runtime, String t_job, String t_dpdate, String t_dpanddate, String t_program1,
			String t_program2, String t_exp1, String t_exp2, String t_exp3, String t_exp4, String t_exp5, String t_exp6,
			String t_exp7, String t_exp8, String t_exp9) {
		super();
		this.no = no;
		this.t_name = t_name;
		this.t_age = t_age;
		this.t_gender = t_gender;
		this.t_birth = t_birth;
		this.t_phone = t_phone;
		this.t_adress = t_adress;
		this.t_runtime = t_runtime;
		this.t_job = t_job;
		this.t_dpdate = t_dpdate;
		this.t_dpanddate = t_dpanddate;
		this.t_program1 = t_program1;
		this.t_program2 = t_program2;
		this.t_exp1 = t_exp1;
		this.t_exp2 = t_exp2;
		this.t_exp3 = t_exp3;
		this.t_exp4 = t_exp4;
		this.t_exp5 = t_exp5;
		this.t_exp6 = t_exp6;
		this.t_exp7 = t_exp7;
		this.t_exp8 = t_exp8;
		this.t_exp9 = t_exp9;
	}

	public TrainerVO(String t_name, String t_age, String t_gender, String t_birth, String t_phone, String t_adress,
			String t_runtime, String t_job, String t_dpdate, String t_dpanddate, String t_program1, String t_program2,
			String t_exp1, String t_exp2, String t_exp3, String t_exp4, String t_exp5, String t_exp6, String t_exp7,
			String t_exp8, String t_exp9) {
		super();
		this.t_name = t_name;
		this.t_age = t_age;
		this.t_gender = t_gender;
		this.t_birth = t_birth;
		this.t_phone = t_phone;
		this.t_adress = t_adress;
		this.t_runtime = t_runtime;
		this.t_job = t_job;
		this.t_dpdate = t_dpdate;
		this.t_dpanddate = t_dpanddate;
		this.t_program1 = t_program1;
		this.t_program2 = t_program2;
		this.t_exp1 = t_exp1;
		this.t_exp2 = t_exp2;
		this.t_exp3 = t_exp3;
		this.t_exp4 = t_exp4;
		this.t_exp5 = t_exp5;
		this.t_exp6 = t_exp6;
		this.t_exp7 = t_exp7;
		this.t_exp8 = t_exp8;
		this.t_exp9 = t_exp9;
	}

	public TrainerVO(int no, String t_name, String t_age, String t_gender, String t_birth, String t_phone,
			String t_adress, String t_runtime, String t_job, String t_dpdate, String t_dpanddate, String t_program1,
			String t_program2, String t_exp1, String t_exp2, String t_exp3, String t_exp4, String t_exp5, String t_exp6,
			String t_exp7, String t_exp8, String t_exp9, String t_image) {
		super();
		this.no = no;
		this.t_name = t_name;
		this.t_age = t_age;
		this.t_gender = t_gender;
		this.t_birth = t_birth;
		this.t_phone = t_phone;
		this.t_adress = t_adress;
		this.t_runtime = t_runtime;
		this.t_job = t_job;
		this.t_dpdate = t_dpdate;
		this.t_dpanddate = t_dpanddate;
		this.t_program1 = t_program1;
		this.t_program2 = t_program2;
		this.t_exp1 = t_exp1;
		this.t_exp2 = t_exp2;
		this.t_exp3 = t_exp3;
		this.t_exp4 = t_exp4;
		this.t_exp5 = t_exp5;
		this.t_exp6 = t_exp6;
		this.t_exp7 = t_exp7;
		this.t_exp8 = t_exp8;
		this.t_exp9 = t_exp9;
		this.t_image = t_image;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getT_name() {
		return t_name;
	}

	public void setT_name(String t_name) {
		this.t_name = t_name;
	}

	public String getT_age() {
		return t_age;
	}

	public void setT_age(String t_age) {
		this.t_age = t_age;
	}

	public String getT_gender() {
		return t_gender;
	}

	public void setT_gender(String t_gender) {
		this.t_gender = t_gender;
	}

	public String getT_birth() {
		return t_birth;
	}

	public void setT_birth(String t_birth) {
		this.t_birth = t_birth;
	}

	public String getT_phone() {
		return t_phone;
	}

	public void setT_phone(String t_phone) {
		this.t_phone = t_phone;
	}

	public String getT_adress() {
		return t_adress;
	}

	public void setT_adress(String t_adress) {
		this.t_adress = t_adress;
	}

	public String getT_runtime() {
		return t_runtime;
	}

	public void setT_runtime(String t_runtime) {
		this.t_runtime = t_runtime;
	}

	public String getT_job() {
		return t_job;
	}

	public void setT_job(String t_job) {
		this.t_job = t_job;
	}

	public String getT_dpdate() {
		return t_dpdate;
	}

	public void setT_dpdate(String t_dpdate) {
		this.t_dpdate = t_dpdate;
	}

	public String getT_dpanddate() {
		return t_dpanddate;
	}

	public void setT_dpanddate(String t_dpanddate) {
		this.t_dpanddate = t_dpanddate;
	}

	public String getT_program1() {
		return t_program1;
	}

	public void setT_program1(String t_program1) {
		this.t_program1 = t_program1;
	}

	public String getT_program2() {
		return t_program2;
	}

	public void setT_program2(String t_program2) {
		this.t_program2 = t_program2;
	}

	public String getT_exp1() {
		return t_exp1;
	}

	public void setT_exp1(String t_exp1) {
		this.t_exp1 = t_exp1;
	}

	public String getT_exp2() {
		return t_exp2;
	}

	public void setT_exp2(String t_exp2) {
		this.t_exp2 = t_exp2;
	}

	public String getT_exp3() {
		return t_exp3;
	}

	public void setT_exp3(String t_exp3) {
		this.t_exp3 = t_exp3;
	}

	public String getT_exp4() {
		return t_exp4;
	}

	public void setT_exp4(String t_exp4) {
		this.t_exp4 = t_exp4;
	}

	public String getT_exp5() {
		return t_exp5;
	}

	public void setT_exp5(String t_exp5) {
		this.t_exp5 = t_exp5;
	}

	public String getT_exp6() {
		return t_exp6;
	}

	public void setT_exp6(String t_exp6) {
		this.t_exp6 = t_exp6;
	}

	public String getT_exp7() {
		return t_exp7;
	}

	public void setT_exp7(String t_exp7) {
		this.t_exp7 = t_exp7;
	}

	public String getT_exp8() {
		return t_exp8;
	}

	public void setT_exp8(String t_exp8) {
		this.t_exp8 = t_exp8;
	}

	public String getT_exp9() {
		return t_exp9;
	}

	public void setT_exp9(String t_exp9) {
		this.t_exp9 = t_exp9;
	}

	public String getT_image() {
		return t_image;
	}

	public void setT_image(String t_image) {
		this.t_image = t_image;
	}

	

}
