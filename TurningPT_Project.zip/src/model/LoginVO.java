package model;

import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginVO {
	private TextField txtLogin;		//�α���
	private PasswordField txtPW;		//�н�����
	
	public LoginVO() {
	}

	public LoginVO(TextField txtLogin, PasswordField txtPW) {
		this.txtLogin = txtLogin;
		this.txtPW = txtPW;
	}

	public TextField getTxtLogin() {
		return txtLogin;
	}

	public void setTxtLogin(TextField txtLogin) {
		this.txtLogin = txtLogin;
	}

	public PasswordField getTxtPW() {
		return txtPW;
	}

	public void setTxtPW(PasswordField txtPW) {
		this.txtPW = txtPW;
	}
	
	
}