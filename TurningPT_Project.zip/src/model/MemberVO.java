package model;

public class MemberVO {
	private int no; // ��������ȣ
	private String m_name; // �̸�1
	private String m_age; // ����2
	private String m_gender; // ����3
	private String m_phone; // ��ȭ��ȣ4
	private String m_birth; // �������5
	private String m_job; // ����
	private String m_character; // �米��6
	private String m_register; // �����7
	private String m_registerand;// ����ϸ���8
	private String m_regiNo; // ���ϰ��� ��9
	private String m_trainer; // ���Ʈ���̳�10
	private String m_type; // ȸ������(PT,OT)11
	private String m_sessionPT; // PT���� ��12
	private String m_sessionOT; // OT�� �� ��13
	private String m_level; // �뵿�ǰ���14
	private String m_runtime; // �ٹ��ð�15
	private String m_runday; // �ٹ�����16
	private String m_rundate; // �ٹ��ϼ�17
	private String m_smoking; // ��������18
	private String m_drinking; // ���ֿ���19
	private String m_reason; // �����20
	private String m_medical; // ����21
	private String m_image; // �̹���22

	public MemberVO() {
	}

	
	public MemberVO(String m_name, String m_age, String m_gender, String m_phone, String m_birth, String m_job,
			String m_character, String m_register, String m_registerand, String m_regiNo, String m_trainer,
			String m_type, String m_sessionPT, String m_sessionOT, String m_level, String m_runtime, String m_runday,
			String m_rundate, String m_smoking, String m_drinking, String m_reason, String m_medical, String m_image) {
		this.m_name = m_name;
		this.m_age = m_age;
		this.m_gender = m_gender;
		this.m_phone = m_phone;
		this.m_birth = m_birth;
		this.m_job = m_job;
		this.m_character = m_character;
		this.m_register = m_register;
		this.m_registerand = m_registerand;
		this.m_regiNo = m_regiNo;
		this.m_trainer = m_trainer;
		this.m_type = m_type;
		this.m_sessionPT = m_sessionPT;
		this.m_sessionOT = m_sessionOT;
		this.m_level = m_level;
		this.m_runtime = m_runtime;
		this.m_runday = m_runday;
		this.m_rundate = m_rundate;
		this.m_smoking = m_smoking;
		this.m_drinking = m_drinking;
		this.m_reason = m_reason;
		this.m_medical = m_medical;
		this.m_image = m_image;
	}

	public MemberVO(int no, String m_name, String m_age, String m_gender, String m_phone, String m_birth, String m_job,
			String m_character, String m_register, String m_registerand, String m_regiNo, String m_trainer,
			String m_type, String m_sessionPT, String m_sessionOT, String m_level, String m_runtime, String m_runday,
			String m_rundate, String m_smoking, String m_drinking, String m_reason, String m_medical, String m_image) {
		this.no = no;
		this.m_name = m_name;
		this.m_age = m_age;
		this.m_gender = m_gender;
		this.m_phone = m_phone;
		this.m_birth = m_birth;
		this.m_job = m_job;
		this.m_character = m_character;
		this.m_register = m_register;
		this.m_registerand = m_registerand;
		this.m_regiNo = m_regiNo;
		this.m_trainer = m_trainer;
		this.m_type = m_type;
		this.m_sessionPT = m_sessionPT;
		this.m_sessionOT = m_sessionOT;
		this.m_level = m_level;
		this.m_runtime = m_runtime;
		this.m_runday = m_runday;
		this.m_rundate = m_rundate;
		this.m_smoking = m_smoking;
		this.m_drinking = m_drinking;
		this.m_reason = m_reason;
		this.m_medical = m_medical;
		this.m_image = m_image;
	}

	
	public MemberVO(int no, String m_name, String m_age, String m_gender, String m_phone, String m_birth, String m_job,
			String m_character, String m_register, String m_registerand, String m_regiNo, String m_trainer,
			String m_type, String m_sessionPT, String m_sessionOT, String m_level, String m_runtime, String m_runday,
			String m_rundate, String m_smoking, String m_drinking, String m_reason, String m_medical) {
		super();
		this.no = no;
		this.m_name = m_name;
		this.m_age = m_age;
		this.m_gender = m_gender;
		this.m_phone = m_phone;
		this.m_birth = m_birth;
		this.m_job = m_job;
		this.m_character = m_character;
		this.m_register = m_register;
		this.m_registerand = m_registerand;
		this.m_regiNo = m_regiNo;
		this.m_trainer = m_trainer;
		this.m_type = m_type;
		this.m_sessionPT = m_sessionPT;
		this.m_sessionOT = m_sessionOT;
		this.m_level = m_level;
		this.m_runtime = m_runtime;
		this.m_runday = m_runday;
		this.m_rundate = m_rundate;
		this.m_smoking = m_smoking;
		this.m_drinking = m_drinking;
		this.m_reason = m_reason;
		this.m_medical = m_medical;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getM_name() {
		return m_name;
	}

	public void setM_name(String m_name) {
		this.m_name = m_name;
	}

	public String getM_age() {
		return m_age;
	}

	public void setM_age(String m_age) {
		this.m_age = m_age;
	}

	public String getM_gender() {
		return m_gender;
	}

	public void setM_gender(String m_gender) {
		this.m_gender = m_gender;
	}

	public String getM_phone() {
		return m_phone;
	}

	public void setM_phone(String m_phone) {
		this.m_phone = m_phone;
	}

	public String getM_birth() {
		return m_birth;
	}

	public void setM_birth(String m_birth) {
		this.m_birth = m_birth;
	}

	public String getM_job() {
		return m_job;
	}

	public void setM_job(String m_job) {
		this.m_job = m_job;
	}

	public String getM_character() {
		return m_character;
	}

	public void setM_character(String m_character) {
		this.m_character = m_character;
	}

	public String getM_register() {
		return m_register;
	}

	public void setM_register(String m_register) {
		this.m_register = m_register;
	}

	public String getM_registerand() {
		return m_registerand;
	}

	public void setM_registerand(String m_registerand) {
		this.m_registerand = m_registerand;
	}

	public String getM_regiNo() {
		return m_regiNo;
	}

	public void setM_regiNo(String m_regiNo) {
		this.m_regiNo = m_regiNo;
	}

	public String getM_trainer() {
		return m_trainer;
	}

	public void setM_trainer(String m_trainer) {
		this.m_trainer = m_trainer;
	}

	public String getM_type() {
		return m_type;
	}

	public void setM_type(String m_type) {
		this.m_type = m_type;
	}

	public String getM_sessionPT() {
		return m_sessionPT;
	}

	public void setM_sessionPT(String m_sessionPT) {
		this.m_sessionPT = m_sessionPT;
	}

	public String getM_sessionOT() {
		return m_sessionOT;
	}

	public void setM_sessionOT(String m_sessionOT) {
		this.m_sessionOT = m_sessionOT;
	}

	public String getM_level() {
		return m_level;
	}

	public void setM_level(String m_level) {
		this.m_level = m_level;
	}

	public String getM_runtime() {
		return m_runtime;
	}

	public void setM_runtime(String m_runtime) {
		this.m_runtime = m_runtime;
	}

	public String getM_runday() {
		return m_runday;
	}

	public void setM_runday(String m_runday) {
		this.m_runday = m_runday;
	}

	public String getM_rundate() {
		return m_rundate;
	}

	public void setM_rundate(String m_rundate) {
		this.m_rundate = m_rundate;
	}

	public String getM_smoking() {
		return m_smoking;
	}

	public void setM_smoking(String m_smoking) {
		this.m_smoking = m_smoking;
	}

	public String getM_drinking() {
		return m_drinking;
	}

	public void setM_drinking(String m_drinking) {
		this.m_drinking = m_drinking;
	}

	public String getM_reason() {
		return m_reason;
	}

	public void setM_reason(String m_reason) {
		this.m_reason = m_reason;
	}

	public String getM_medical() {
		return m_medical;
	}

	public void setM_medical(String m_medical) {
		this.m_medical = m_medical;
	}

	public String getM_image() {
		return m_image;
	}

	public void setM_image(String m_image) {
		this.m_image = m_image;
	}

}
