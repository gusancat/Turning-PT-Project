package model;

public class ProfileVO {
	private String p_image1;
	private String p_image2;
	private String p_image3;
	private String p_image4;
	private String p_image5;
	private String p_image6;
	private String p_image7;
	private String p_image8;
	
	public ProfileVO() {
	}

	public ProfileVO(String p_image1, String p_image2, String p_image3, String p_image4, String p_image5,
			String p_image6, String p_image7, String p_image8) {
		this.p_image1 = p_image1;
		this.p_image2 = p_image2;
		this.p_image3 = p_image3;
		this.p_image4 = p_image4;
		this.p_image5 = p_image5;
		this.p_image6 = p_image6;
		this.p_image7 = p_image7;
		this.p_image8 = p_image8;
	}

	public String getP_image1() {
		return p_image1;
	}

	public void setP_image1(String p_image1) {
		this.p_image1 = p_image1;
	}

	public String getP_image2() {
		return p_image2;
	}

	public void setP_image2(String p_image2) {
		this.p_image2 = p_image2;
	}

	public String getP_image3() {
		return p_image3;
	}

	public void setP_image3(String p_image3) {
		this.p_image3 = p_image3;
	}

	public String getP_image4() {
		return p_image4;
	}

	public void setP_image4(String p_image4) {
		this.p_image4 = p_image4;
	}

	public String getP_image5() {
		return p_image5;
	}

	public void setP_image5(String p_image5) {
		this.p_image5 = p_image5;
	}

	public String getP_image6() {
		return p_image6;
	}

	public void setP_image6(String p_image6) {
		this.p_image6 = p_image6;
	}

	public String getP_image7() {
		return p_image7;
	}

	public void setP_image7(String p_image7) {
		this.p_image7 = p_image7;
	}

	public String getP_image8() {
		return p_image8;
	}

	public void setP_image8(String p_image8) {
		this.p_image8 = p_image8;
	}
}
