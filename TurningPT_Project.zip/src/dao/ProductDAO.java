package dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import application.DBUtil;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.MemberVO;
import model.ProductVO;

public class ProductDAO {

	// ��೻�� ���
	public ProductVO getProductSave(ProductVO pvo, int no) throws Exception {
		String register = pvo.getP_register();
		/*String sql = "insert into contract values (contract_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ?)"; // 8��
*/		String sql = "insert into product" + "(no, p_membername, p_program, p_productjoin, p_monthpay, p_productmax, p_productlesson, p_register)"
	            + "values(product_seq.nextval,?,?,?,?,?,?,to_date('"+register+"','YYYY-MM-DD'))";
 
		Connection con = null;
		PreparedStatement pstmt = null;
		ProductVO pVO = null;
		boolean joinSucess = false;

		try {

			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, pvo.getP_membername());
			pstmt.setString(2, pvo.getP_program());
			pstmt.setString(3, pvo.getP_productjoin());
			pstmt.setString(4, pvo.getP_monthpay());
			pstmt.setString(5, pvo.getP_productmax());
			pstmt.setString(6, pvo.getP_productlesson());

			int i = pstmt.executeUpdate();
			pVO = new ProductVO();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���α׷� ���");
				alert.setHeaderText("���α׷���� �Ϸ�");
				alert.setContentText("���α׷� ��� ����");
				alert.showAndWait();
				joinSucess = true;
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���α׷� ���");
				alert.setHeaderText("���α׷� ��Ͻ���");
				alert.setContentText("���α׷� ��Ͻ���");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println("��ǰ���� DAO = [" + e + "]");
		} catch (Exception e) {
			System.out.println("��ǰ���� DAO = [" + e + "]");
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (con != null)
				con.close();
		}
		return pVO;
	}

	// ��ǰ�� member name�� �Է¹޾� ������ȸ
	public ProductVO getProductCheck(String name) {
		String sql = "select * from product where p_membername = ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProductVO pVO = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				pVO = new ProductVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8).toString());

			}
		} catch (Exception e) {
			System.out.println("���DAO ��ȸ ���� "+e);
		} finally {
			try {
				if (rs != null);
				rs.close();
				if (pstmt != null);
				pstmt.close();
				if (con != null);
				con.close();
			} catch (Exception e) {
			}
		}
		return pVO;
	}


	// ������� ����
	public ProductVO getProductEdit(ProductVO pvo, int no) throws Exception {
		StringBuffer sql = new StringBuffer();
	      sql.append("update product set ");
	      sql.append(" p_membername=?, p_program=?, p_productjoin=?, p_monthpay = ?, p_productmax= ?, p_productlesson, p_register=? ");
	      sql.append(" where no = ?");
	      // ���ڸ� 1��° ���� 10��°������ �о ����ϵ��� ����°�
	      String i1 = pvo.getP_register().substring(0, 10);
	      LocalDate ld1 = LocalDate.parse(i1);
	      Connection con = null;
	      PreparedStatement pstmt = null;
	      ProductVO retval = null;
	      try {
	         con = DBUtil.getConnection();

	         pstmt = con.prepareStatement(sql.toString());
	         
	         pstmt.setString(1, pvo.getP_membername());
	         pstmt.setString(2, pvo.getP_program());
	         pstmt.setString(3, pvo.getP_productjoin());
	         pstmt.setString(4, pvo.getP_monthpay());
	         pstmt.setString(5, pvo.getP_productmax());
	         pstmt.setString(6, pvo.getP_productlesson());
	         pstmt.setString(7, ld1.toString());
	         pstmt.setInt(8, no);

	         int i = pstmt.executeUpdate();

	         if (i == 1) {
	            Alert alert = new Alert(AlertType.INFORMATION);
	            alert.setTitle(" ���α׷� ���� ");
	            alert.setHeaderText(" ���α׷� ���� �Ϸ� .");
	            alert.setContentText("���α׷� ���� ���� !!!");
	            alert.showAndWait();
	            retval = new ProductVO();
	         } else {
	            Alert alert = new Alert(AlertType.INFORMATION);
	            alert.setTitle("���α׷� ���� ");
	            alert.setHeaderText("���α׷� ���� ���� .");
	            alert.setContentText("���α׷� ���� ���� !!!");
	            alert.showAndWait();
	            System.out.println("���� ���ް� :" + i);
	         }
	      } catch (SQLException e) {
	       
	      } catch (Exception e) {
	         System.out.println("���α׷���������" + e );
	      } finally {
	         try {
	            if (pstmt != null)
	               pstmt.close();
	            if (con != null)
	               con.close();
	         } catch (SQLException e) {
	         }
	      }
	      return retval;
	   }

	// ��ǰ ����
	public void getProductDelete(int no) {
		String sql = "delete from product where no = ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���α׷� ����");
				alert.setHeaderText("���α׷����� �Ϸ�");
				alert.setContentText("���α׷����� ����");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���α׷� ����");
				alert.setHeaderText("���α׷� ����");
				alert.setContentText("���α׷� ����");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("��ǰ���� DAO" + e);
		} catch (Exception e) {
			System.out.println("��ǰ���� DAO" + e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	// ��ǰ���� ��ü ����Ʈ SQL��
	public ArrayList<ProductVO> getProductTotalList() {
		ArrayList<ProductVO> list = new ArrayList<ProductVO>();
		String sql = "select * from product";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProductVO totalVO = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();

			while (rs.next()) {
				totalVO = new ProductVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));
				

				/*totalVO = new ProductVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
				rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8),totalVO.setP_register(rs.getDate("j_day") + ""));
				list.add(totalVO);*/
				list.add(totalVO);
			}
		} catch (SQLException e) {
			System.out.println("��ǰ ��ü����Ʈ DAO " + e);
		} catch (Exception e) {
			System.out.println("��ǰ ��ü����Ʈ DAO " + e);
		} finally {
			try {

				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {

			}
		}
		return list;
	}

	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from product";
		Connection con = null;
		PreparedStatement sptmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			sptmt = con.prepareStatement(sql);
			rs = sptmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException e) {
			System.out.println("��ǰ DAO"+e);
		} catch (Exception e) {
			System.out.println("��ǰ DAO"+e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (sptmt != null)
					sptmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {

			}
		}
		return columnName;
	}
}
