package dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import application.DBUtil;

public class LoginDAO {
	
	public boolean getLogin(String Login, String PW) throws Exception{
		String sql = "select * from login where login = ? and pw = ? ";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		boolean loginResult = false;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, Login);
			pstmt.setString(2, PW);
			rs = pstmt.executeQuery();
					
			if(rs.next()) {
				loginResult = true;			//ID �� PW�� ��ġ�Ѵ�.
			}
		}catch(SQLException e){
			System.out.println("e=["+e+"]");
		}catch(Exception e) {
			System.out.println("e=["+e+"]");
		}finally {
			try {
				if(rs != null)
					rs.close();
				if(pstmt != null)
					pstmt.close();
				if(con != null)
					con.close();
			}catch(Exception e) {
			}
		}
		return loginResult;
	}
}