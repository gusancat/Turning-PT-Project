package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import application.DBUtil;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.ProfileVO;

public class ProfileDAO {
	public ProfileVO getProfileUpdate(ProfileVO pvo, int no) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("update profile set ");
		sql.append("p_image1=?, p_image2=?, p_image3=?, p_image4 = ?, p_image5= ?, p_image6=?, p_image7=?, p_image8=?");
		// ���ڸ� 1��° ���� 10��°������ �о ����ϵ��� ����°�
		Connection con = null;
		PreparedStatement pstmt = null;
		ProfileVO retval = null;
		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(sql.toString());

			pstmt.setString(1, pvo.getP_image1());
			pstmt.setString(2, pvo.getP_image2());
			pstmt.setString(3, pvo.getP_image3());
			pstmt.setString(4, pvo.getP_image4());
			pstmt.setString(5, pvo.getP_image5());
			pstmt.setString(6, pvo.getP_image6());
			pstmt.setString(7, pvo.getP_image7());
			pstmt.setString(8, pvo.getP_image8());

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle(" ���� ���� ");
				alert.setHeaderText(" �������� �Ϸ� .");
				alert.setContentText(" �������� ���� !!!");
				alert.showAndWait();
				retval = new ProfileVO();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle(" ���� ���� ");
				alert.setHeaderText(" �������� ���� .");
				alert.setContentText("�������� ���� !!!");
				alert.showAndWait();
				System.out.println("���� ���ް� :" + i);
			}
		} catch (SQLException e) {
		} catch (Exception e) {
			System.out.println("ȸ����������" + e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return retval;
	}
	
	
	// �ű�ȸ�� ���� ���
		public ProfileVO getProfileInfoSave(ProfileVO profileInfoVO) throws Exception {
			String sql = "insert into profile values (?, ?, ?, ?, ?, ?, ?, ?)"; 
			Connection con = null;																																
			PreparedStatement pstmt = null;
			ProfileVO pVO = null;
			boolean joinSucess = false;

			try {

				con = DBUtil.getConnection();
				pstmt = con.prepareStatement(sql.toString());
				pstmt.setString(1, profileInfoVO.getP_image1());
				pstmt.setString(1, profileInfoVO.getP_image2());
				pstmt.setString(1, profileInfoVO.getP_image3());
				pstmt.setString(1, profileInfoVO.getP_image4());
				pstmt.setString(1, profileInfoVO.getP_image5());
				pstmt.setString(1, profileInfoVO.getP_image6());
				pstmt.setString(1, profileInfoVO.getP_image7());
				pstmt.setString(1, profileInfoVO.getP_image8());

				int i = pstmt.executeUpdate();
				pVO = new ProfileVO();

				if (i == 1) {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle(" ���");
					alert.setHeaderText("ȸ������ ��ϿϷ�");
					alert.setContentText("ȸ������ ��ϼ���");
					alert.showAndWait();
					joinSucess = true;
				} else {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("ȸ������ ���");
					alert.setHeaderText("ȸ������ ��Ͻ���");
					alert.setContentText("ȸ������ ��Ͻ���");
					alert.showAndWait();
				}
			} catch (SQLException e) {
				System.out.println("���� = [" + e + "]");
			} catch (Exception e) {
				System.out.println("���� = [" + e + "]");
			} finally {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			}
			return pVO;
		}
	
}
