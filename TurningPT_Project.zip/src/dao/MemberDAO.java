package dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Formatter;

import application.DBUtil;
import control.InfoControl;
import control.MemberControl;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.ImageView;
import model.MemberVO;

public class MemberDAO {

	// ȸ������ ����
	public MemberVO getMemberUpdate(MemberVO mvo, int no) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("update member set ");
		sql.append(
				" m_name=?, m_age=?, m_gender=?, m_phone = ?, m_birth= ?, m_job=?, m_character=?, m_register=?, m_registerand=?, m_regino=?, m_trainer=?, m_type=?, m_sessionpt=?"
						+ "m_sessionot=?, m_level=?, m_runtime=?, m_runday=?, m_rundate=?, m_smoking=?, m_drinking=?, m_reason=?, m_medical=?, m_image=? ");
		sql.append(" where no = ?");
		// ���ڸ� 1��° ���� 10��°������ �о ����ϵ��� ����°�
		String i1 = mvo.getM_register().substring(0, 10);
		String i2 = mvo.getM_registerand().substring(0, 10);
		LocalDate ld1 = LocalDate.parse(i1);
		LocalDate ld2 = LocalDate.parse(i2);
		Connection con = null;
		PreparedStatement pstmt = null;
		MemberVO retval = null;
		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, mvo.getM_name());
			pstmt.setString(2, mvo.getM_age());
			pstmt.setString(3, mvo.getM_gender());
			pstmt.setString(4, mvo.getM_phone());
			pstmt.setString(5, mvo.getM_birth());
			pstmt.setString(6, mvo.getM_job());
			pstmt.setString(7, mvo.getM_character());
			pstmt.setString(8, ld1.toString());
			pstmt.setString(9, ld2.toString());
			pstmt.setString(10, mvo.getM_regiNo());
			pstmt.setString(11, mvo.getM_trainer());
			pstmt.setString(12, mvo.getM_type());
			pstmt.setString(13, mvo.getM_sessionPT());
			pstmt.setString(14, mvo.getM_sessionOT());
			pstmt.setString(15, mvo.getM_level());
			pstmt.setString(16, mvo.getM_runtime());
			pstmt.setString(17, mvo.getM_runday());
			pstmt.setString(18, mvo.getM_rundate());
			pstmt.setString(19, mvo.getM_smoking());
			pstmt.setString(20, mvo.getM_drinking());
			pstmt.setString(21, mvo.getM_reason());
			pstmt.setString(22, mvo.getM_medical());
			pstmt.setString(23, mvo.getM_image());
			pstmt.setInt(24, no);
			int i = pstmt.executeUpdate();
					System.out.println(i);
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle(" ���� ���� ");
				alert.setHeaderText(" ���� ���� �Ϸ� .");
				alert.setContentText(" ���� ���� ���� !!!");
				alert.showAndWait();
				retval = new MemberVO();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle(" ���� ���� ");
				alert.setHeaderText(" ���� ���� ���� .");
				alert.setContentText(" ���� ���� ���� !!!");
				alert.showAndWait();
				System.out.println("���� ���ް� :" + i);
			}
		} catch (SQLException e) {
		} catch (Exception e) {
			System.out.println("ȸ����������" + e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return retval;
	}

	// �ű�ȸ�� ���� ���
	public MemberVO getMemberInfoSave(MemberVO memberInfoVO) throws Exception {
		String day = memberInfoVO.getM_register().toString();
		String sql = "insert into member values (member_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"; // m_register('"
																																			// day
		// "', 'YYYY-MM-DD')
		Connection con = null;
		PreparedStatement pstmt = null;
		MemberVO mVO = null;
		boolean joinSucess = false;

		try {

			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, memberInfoVO.getM_name());
			pstmt.setString(2, memberInfoVO.getM_age());
			pstmt.setString(3, memberInfoVO.getM_gender());
			pstmt.setString(4, memberInfoVO.getM_phone());
			pstmt.setString(5, memberInfoVO.getM_birth());
			pstmt.setString(6, memberInfoVO.getM_job());
			pstmt.setString(7, memberInfoVO.getM_character());
			pstmt.setString(8, memberInfoVO.getM_register().toString());
			pstmt.setString(9, memberInfoVO.getM_registerand().toString());
			pstmt.setString(10, memberInfoVO.getM_regiNo());
			pstmt.setString(11, memberInfoVO.getM_trainer());
			pstmt.setString(12, memberInfoVO.getM_type());
			pstmt.setString(13, memberInfoVO.getM_sessionPT());
			pstmt.setString(14, memberInfoVO.getM_sessionOT());
			pstmt.setString(15, memberInfoVO.getM_level());
			pstmt.setString(16, memberInfoVO.getM_runtime());
			pstmt.setString(17, memberInfoVO.getM_runday());
			pstmt.setString(18, memberInfoVO.getM_rundate());
			pstmt.setString(19, memberInfoVO.getM_smoking());
			pstmt.setString(20, memberInfoVO.getM_drinking());
			pstmt.setString(21, memberInfoVO.getM_reason());
			pstmt.setString(22, memberInfoVO.getM_medical());
			pstmt.setString(23, memberInfoVO.getM_image());

			int i = pstmt.executeUpdate();
			mVO = new MemberVO();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ������ ���");
				alert.setHeaderText("ȸ������ ��ϿϷ�");
				alert.setContentText("ȸ������ ��ϼ���");
				alert.showAndWait();
				joinSucess = true;
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ������ ���");
				alert.setHeaderText("ȸ������ ��Ͻ���");
				alert.setContentText("ȸ������ ��Ͻ���");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println("���� = [" + e + "]");
		} catch (Exception e) {
			System.out.println("���� = [" + e + "]");
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (con != null)
				con.close();
		}
		return memberInfoVO;
	}

	// ȸ���� name�� �Է¹޾� ������ȸ
	public MemberVO getMemberCheck(String name) {
		String sql = "select * from member where m_name = ?";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MemberVO memberVO = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				memberVO = new MemberVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8).toString(),
						rs.getString(9).toString(), rs.getString(10), rs.getString(11), rs.getString(12),
						rs.getString(13), rs.getString(14), rs.getString(15), rs.getString(16), rs.getString(17),
						rs.getString(18), rs.getString(19), rs.getString(20), rs.getString(21), rs.getString(22),
						rs.getString(23), rs.getString(24));

			}
		} catch (Exception e) {
			System.out.println("���DAO ��ȸ ���� " + e);
		} finally {
			try {
				if (rs != null)
					;
				rs.close();
				if (pstmt != null)
					;
				pstmt.close();
				if (con != null)
					;
				con.close();
			} catch (Exception e) {

			}
		}
		return memberVO;

	}

	// ȸ������ ��ü ����Ʈ SQL��
	public ArrayList<MemberVO> getMemberTotalList() {
		ArrayList<MemberVO> list = new ArrayList<MemberVO>();
		String sql = "select * from member";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MemberVO totalVO = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			System.out.println("0000");
			while (rs.next()) {
				totalVO = new MemberVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8).toString(), rs.getString(9).toString(),
						rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14),
						rs.getString(15), rs.getString(16), rs.getString(17), rs.getString(18), rs.getString(19),
						rs.getString(20), rs.getString(21), rs.getString(22), rs.getString(23), rs.getString(24));
				System.out.println("2222");
				list.add(totalVO);
				System.out.println("333");
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
		} finally {
			try {

				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {

			}
		}
		return list;
	}

	// �л����� ������ ���� SQL��
	public void getMemberDelete(int no) {
		String sql = "delete from member where no = ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ�� ����");
				alert.setHeaderText("ȸ������ �Ϸ�");
				alert.setContentText("ȸ������ ����");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ�� ����");
				alert.setHeaderText("ȸ������ ����");
				alert.setContentText("ȸ������ ����");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from member";
		Connection con = null;
		PreparedStatement sptmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			sptmt = con.prepareStatement(sql);
			rs = sptmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (sptmt != null)
					sptmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {

			}
		}
		return columnName;
	}
}
