package dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Formatter;

import application.DBUtil;
import control.InfoControl;
import control.MemberControl;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.ImageView;
import model.MemberVO;
import model.TrainerVO;

public class TrainerDAO {

	public TrainerVO getTrainerUpdate(TrainerVO tvo, int no) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("update trainer set ");
		sql.append(
				" t_name=?, t_age=?, t_gender=?, t_birth= ?, t_phone = ?, t_adress=?, t_runtime=?, t_job=?, t_dpdate=?, t_dpanddate=?, "
						+ "t_program1=?, t_program2=?, t_exp1=?, t_exp2=?, t_exp3=?, t_exp4=? ,t_exp5=? ,t_exp6=? ,t_exp7=?, t_exp8=?, t_exp9=?, t_image=? ");
		sql.append(" where no = ?");
		// ���ڸ� 1��° ���� 10��°������ �о ����ϵ��� ����°�
		String i1 = tvo.getT_dpdate().substring(0, 10);
		String i2 = tvo.getT_dpanddate().substring(0, 10);
		LocalDate ld = LocalDate.parse(i1);

		Connection con = null;
		PreparedStatement pstmt = null;
		TrainerVO retval = null;
		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(sql.toString());

			pstmt.setString(1, tvo.getT_name());
			pstmt.setString(2, tvo.getT_age());
			pstmt.setString(3, tvo.getT_gender());
			pstmt.setString(4, tvo.getT_birth());
			pstmt.setString(5, tvo.getT_phone());
			pstmt.setString(6, tvo.getT_adress());
			pstmt.setString(7, tvo.getT_runtime());
			pstmt.setString(8, tvo.getT_job());
			pstmt.setString(9, ld.toString());
			pstmt.setString(10, tvo.getT_dpanddate().toString());
			pstmt.setString(11, tvo.getT_program1());
			pstmt.setString(12, tvo.getT_program2());
			pstmt.setString(13, tvo.getT_exp1());
			pstmt.setString(14, tvo.getT_exp2());
			pstmt.setString(15, tvo.getT_exp3());
			pstmt.setString(16, tvo.getT_exp4());
			pstmt.setString(17, tvo.getT_exp5());
			pstmt.setString(18, tvo.getT_exp6());
			pstmt.setString(19, tvo.getT_exp7());
			pstmt.setString(20, tvo.getT_exp8());
			pstmt.setString(21, tvo.getT_exp9());
			pstmt.setString(22, tvo.getT_image());
			pstmt.setInt(23, no);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle(" Ʈ���̳� ���� ");
				alert.setHeaderText(" Ʈ���̳� ���� �Ϸ� .");
				alert.setContentText(" Ʈ���̳� ���� ���� !!!");
				alert.showAndWait();
				retval = new TrainerVO();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle(" ���� ���� ");
				alert.setHeaderText(" ���� ���� ���� .");
				alert.setContentText(" ���� ���� ���� !!!");
				alert.showAndWait();
				System.out.println("���� ���ް� :" + i);
			}
		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
			System.out.println(tvo.getT_gender());
			System.out.println(tvo.getT_phone());
			System.out.println(no);
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return retval;
	}

		

	// �л����� ������ ���� SQL��
	public void getTrainerDelete(int no) {
		String sql = "delete from trainer where no = ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Ʈ���̳� ����");
				alert.setHeaderText("Ʈ���̳ʻ��� �Ϸ�");
				alert.setContentText("Ʈ���̳ʻ��� ����");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Ʈ���̳� ����");
				alert.setHeaderText("Ʈ���̳ʻ��� ����");
				alert.setContentText("Ʈ���̳ʻ��� ����");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	// �ű�ȸ�� ���� ���
	public TrainerVO getTrainerSave(TrainerVO trainerVO) throws Exception {
		String date = trainerVO.getT_dpdate().toString();
		String anddate = trainerVO.getT_dpanddate().toString();
		String sql = "insert into trainer values (trainer_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ? , ? ,? ,? ,? ,? ,? ,? , ? ,? ,? ,? ,? ,? ,? )";

		Connection con = null;
		PreparedStatement pstmt = null;
		MemberVO mVO = null;
		boolean joinSucess = false;

		try {

			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, trainerVO.getT_name());
			pstmt.setString(2, trainerVO.getT_age());
			pstmt.setString(3, trainerVO.getT_gender());
			pstmt.setString(4, trainerVO.getT_birth());
			pstmt.setString(5, trainerVO.getT_phone());
			pstmt.setString(6, trainerVO.getT_adress());
			pstmt.setString(7, trainerVO.getT_runtime());
			pstmt.setString(8, trainerVO.getT_job());
			pstmt.setString(9, trainerVO.getT_dpdate().toString());
			pstmt.setString(10, trainerVO.getT_dpanddate().toString());
			pstmt.setString(11, trainerVO.getT_program1());
			pstmt.setString(12, trainerVO.getT_program2());
			pstmt.setString(13, trainerVO.getT_exp1());
			pstmt.setString(14, trainerVO.getT_exp2());
			pstmt.setString(15, trainerVO.getT_exp3());
			pstmt.setString(16, trainerVO.getT_exp4());
			pstmt.setString(17, trainerVO.getT_exp5());
			pstmt.setString(18, trainerVO.getT_exp6());
			pstmt.setString(19, trainerVO.getT_exp7());
			pstmt.setString(20, trainerVO.getT_exp8());
			pstmt.setString(21, trainerVO.getT_exp9());
			pstmt.setString(22, trainerVO.getT_image());
			int i = pstmt.executeUpdate();
			mVO = new MemberVO();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Ʈ���̳����� ���");
				alert.setHeaderText("Ʈ���̳����� ��ϿϷ�");
				alert.setContentText("Ʈ���̳����� ��ϼ���");
				alert.showAndWait();
				joinSucess = true;
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Ʈ���̳����� ���");
				alert.setHeaderText("Ʈ���̳����� ��Ͻ���");
				alert.setContentText("Ʈ���̳����� ��Ͻ���");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println("���� = [" + e + "]");
		} catch (Exception e) {
			System.out.println("���� = [" + e + "]");
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (con != null)
				con.close();
		}
		return trainerVO;
	}

	// ȸ���� name�� �Է¹޾� ������ȸ
	public TrainerVO getTrainerCheck(String name) {
		String sql = "select * from trainer where t_name like '%" + name + "%' order by no desc";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TrainerVO tVO = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			// pstmt.setString(1, "%" +name + "%");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				// VO�� �ִ� ����� �ҷ��´�
				/*
				 * tVO.setNo(rs.getInt("no")); tVO.setT_name(rs.getString("t_name"));
				 * tVO.setT_age(rs.getString("t_age"));
				 * tVO.setT_gender(rs.getString("t_gender"));
				 * tVO.setT_birth(rs.getString("t_birth"));
				 * tVO.setT_phone(rs.getString("t_phone"));
				 * tVO.setT_adress(rs.getString("t_adress"));
				 * tVO.setT_runtime(rs.getString("t_runtime"));
				 * tVO.setT_job(rs.getString("t_job")); tVO.setT_pay(rs.getString("t_pay"));
				 * tVO.setT_image(rs.getString("t_image"));
				 * tVO.setT_dpdate(rs.getString("t_dpdate"));
				 * tVO.setT_dpanddate(rs.getString("t_dpanddate"));
				 * tVO.setT_program1(rs.getString("t_program1"));
				 * tVO.setT_program2(rs.getString("t_program2"));
				 * tVO.setT_program3(rs.getString("t_program3"));
				 * tVO.setT_exp1(rs.getString("t_exp1")); tVO.setT_exp2(rs.getString("t_exp2"));
				 * tVO.setT_exp3(rs.getString("t_exp3"));
				 */

				// ���̺��信 �ִ� ���� �ҷ��´�
				tVO = new TrainerVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10),
						rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14), rs.getString(15),
						rs.getString(16), rs.getString(17), rs.getString(18), rs.getString(19), rs.getString(20),
						rs.getString(21), rs.getString(22), rs.getString(23));
			}
		} catch (Exception e) {
			System.out.println("Ʈ���̳�DAO ��ȸ ���� " + e);
		} finally {
			try {
				if (rs != null)
					;
				rs.close();
				if (pstmt != null)
					;
				pstmt.close();
				if (con != null)
					;
				con.close();
			} catch (Exception e) {
			}
		}
		return tVO;
	}

	// ȸ������ ��ü ����Ʈ SQL��
	public ArrayList<TrainerVO> getTrainetTotalList() {
		ArrayList<TrainerVO> list = new ArrayList<TrainerVO>();
		String sql = "select * from trainer";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TrainerVO totalVO = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				totalVO = new TrainerVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9),
						rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14),
						rs.getString(15), rs.getString(16), rs.getString(17), rs.getString(18), rs.getString(19),
						rs.getString(20), rs.getString(21), rs.getString(22), rs.getString(23));
				list.add(totalVO);
			}
		} catch (SQLException e) {
			System.out.println("111");
			System.out.println(e);
		} catch (Exception e) {

		} finally {
			try {

				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {

			}
		}
		return list;
	}

	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from trainer";
		Connection con = null;
		PreparedStatement sptmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			sptmt = con.prepareStatement(sql);
			rs = sptmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (sptmt != null)
					sptmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {

			}
		}
		return columnName;
	}
}
